<?php

	include_once "includes/header.php";
	
	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
	
	$msg = "";

	if(isset($_POST['submit'])){
		$name=$_POST['m_name'];
		$sql="INSERT INTO manufacturers (m_name) VALUES('$name')";

		if ($conn->query($sql) === TRUE) {
		    $msg = "New Manufacturer added successfully!";
		} else {
		    $msg = "Error: " . $sql . "<br>" . $conn->error;
		}

		header("Location:manufacturers.php");
		$conn->close();
		echo $msg;
	}
?> 
 

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add Manufacturer Information</h1>
      <form action="" method="post" class="form-horizontal">
		  
		  <div class="form-group">
            
            <div class="col-sm-8">
			<label class="control-label" for="email">Manufacturer name:</label>
              <input type="text" name="m_name" class="form-control" id="m_name" placeholder="Enter Manufacturer Name" required>
            </div>
          </div>
			<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Submit</button>
            <?php 
              }
            ?>
			  <a href="manufacturers.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
 <div class="col-sm-10 ">

</div>
<?php
	include_once "includes/footer.php";
?>

<script type="text/javascript">
	$(document).ready(function(){
	    $("#m_name").focus();
	});
</script>