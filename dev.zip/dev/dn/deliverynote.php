<?php 

	$folder = basename(dirname(__FILE__));

	echo $folder;
	exit;

	//require_once './config/config.php';

	$sql = "SELECT * from company_info";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$rows = mysqli_num_rows($result);

	if( isset( $_GET['del_note_id'] ) ){
		
		$delNoteId = $_GET['del_note_id'];

		$deliveryNotesSql = "SELECT * from delivery_notes WHERE del_note_id = ?";
		$stmt = $conn->prepare( $deliveryNotesSql );
		$stmt->bind_param( "s", $delNoteId_Param );
		$delNoteId_Param = $delNoteId;

		if ( $stmt->execute() === TRUE ) {

			$stmt->store_result();

			$deliveryNoteItemsSql = "SELECT * from delivery_note_items WHERE del_note_id = ?";
			$stmt2 = $conn->prepare( $deliveryNoteItemsSql );
			$stmt2->bind_param( "s", $delNoteId_Param );
			$delNoteId_Param = $delNoteId;

			if ( $stmt2->execute() === TRUE ) {
				$stmt2->store_result();
			}
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Webdesk Delivery Note</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  <style>
  	.delivary tr td, .delivary tr th{
  		padding:10px 0px !important;
  		border-color:#000000 !important;
  		border-width: 1px !important;
  		font-weight: normal;
  	}
  	.delivary{
  		margin-bottom: 0px;
  	}
  	.delivary tr td p, .delivary tr th p{
  		padding:0px 15px;
  	}
  	.delivary tr td p strong{
  		display: block;
  	}
  	.secondTable tr td p strong{
  		
  	}
  	.first tr td p, .first tr th p{
  		width:210px;
  	}
  	.first tr td img{
  		float: left;
  	}
  	.first tr td p{
  		float: left;
  	}
  	.first tr td{
  		width: 250px;
  	}
  	.borderNone{
  		border:0px !important;
  	}
  	.borderPaddingLeft{
  		border-left: 1px solid #000;
  		padding-left: 5px !important;
  	}
  	.height{
  		height: 80px;
  	}
  	.height tr td{
  		border-top:0px !important;
  	}
  	table{
  		border-color:#000000 !important;
  		margin-bottom: 0px !important
  	}
  	.center{
  		width:700px;
  		margin: 0 auto;
  	}
  </style>
</head>
<body>
	<div class="center">
	  <h2 class="text-center">Delevary Note</h2>            
	  <table class="table table-bordered delivary" style='border-right:0px !important'>
	    <tbody>
	      <tr>
	        <td style='padding:0px !important;border-left:0px !important;border-right:0px !important;border-top:0px !important'><table class="table table first">
			    <tbody>
			      <tr>
			        <td class="borderNone" style='border-right:0px !important;border-left:0px !important'><img src="img/logh.png" alt=""><p>Webdesk Technologies
						36 Indrani Park, 3rd Floor,
						Charu Market
						Kolkata-700033
						GSTIN/UIN: 19AIZPD0561C1Z9
						E-Mail : info@webdesktechnologies.com</p>
					</td>
			      </tr>
			      <tr>
			        <td style='border-right:0px !important; border-bottom: 0px !important;border-left:0px !important'><p>Buyer<br>
						Superintendent of Police Darjeeling
						Darjeeling
						West Bengal, Code : 19</p>
					</td>
			      </tr>
			    </tbody>
			  </table>
			  </td>
	        <td style='padding:0px !important;border-left:0px !important;border-right:0px !important;border-top:0px !important'>            
			  <table class="table">
			    <thead>
			      <tr style='padding:0px !important'>
			        <th ><p>Delivery Note No.<br>
						<strong>WD/CH-00025/17-18</strong></p>
					</th>
			        <th><p>Dated<br>
						<strong>24-Aug-2017</strong></p>
					</th>
			      </tr>
			    </thead>
			    <tbody>
			      <tr>
			        <td></td>
			        <td class="borderPaddingLeft"><p>Mode/Terms of Payment</p></td>
			      </tr>
			      <tr>
			        <td><p>Supplier's Ref.</p></td>
			        <td class="borderPaddingLeft"><p>Moe</p></td>
			      </tr>
			      <tr>
			        <td><p>Buyer's Order No.</p></td>
			        <td class="borderPaddingLeft"><p>Dooley</p></td>
			      </tr>
			      <tr>
			        <td><p>Despatch Document No.</p></td>
			        <td class="borderPaddingLeft"><p>Doe</p></td>
			      </tr>
			      <tr>
			        <td><p>Despatched through</p></td>
			        <td class="borderPaddingLeft"><p>Moe</p></td>
			      </tr>
			      <tr>
			        <td style='border-right: 0px !important;border-bottom: 0px !important'><p>Terms of Delivery</p></td>
			        <td style='border-left: 0px !important;border-top: 0px !important;   border-bottom: 0px !important'></td>
			      </tr>
			    </tbody>
			  </table>
			</td>
	      </tr>
	     
	    </tbody>
	  </table>

	  <table class="table table-bordered delivary secondTable" style='border-top:0px !important'>
	    <thead>
	      <tr>
	        <th><p>Sl no</p></th>
	        <th><p>Description of Goods</p></th>
	        <th><p>Quantity</p></th>
	        <th><p>Rate</p></th>
	        <th><p>per</p></th>
	        <th><p>Amount</p></th>
	      </tr>
	    </thead>
	    <tbody>
	      <tr>
	        <td>
	        	<p><strong>1</strong></p><br>
	        	<p><strong>2</strong></p><br>
	        	<p><strong>3</strong></p><br>
	        	<p><strong>4</strong></p><br>
	        	<p><strong>5</strong></p><br>
	        	<p><strong>6</strong></p><br>
	        	<p><strong>7</strong></p><br>
	        	<p><strong>8</strong></p><br>
	        	
	        </td>
	        <td><p><strong>DS-2CD2T42WD-I3</strong> 
				mp Bullet Network Camera<br></p>
				 <p><strong>DS-2CD2T42WD-I5</strong> 
				Fixed Focus Camera<br></p>
				 <p><strong>DS-7604NI-E1/4P</strong> 
				 Channel POE NVR<br></p>
				 <p><strong>DS-7608NI-E2/8P</strong> 
				 Channel POE NVR<br></p>
				 <p><strong>DS-D5019QE </strong>
				LCD TV
				<p> <strong>ST004VX007</strong> 
				Surveillance Hard Disk 4TB<br></p>
				<p> <strong>MX-3627 UTP CAT6 NETWORKING CABLE </strong>
				Networking Cable<br></p>
				 <p><strong>UPS MICROTEK 1000VA TWINGUARD TGE 1000+ </strong>
				UPS Microtek</p></td>
	        <td><p></p></td>
	        <td><p></p></td>
	        <td><p></p></td>
	        <td><p></p></td>
	      </tr>
	      <tr>
	      	<td><p></p></td>
	      	<td><p class="pull-right">Total</p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      </tr>
	    </tbody>
	  </table>

	  <table class="table table-bordered delivary height">
	    <tbody>
	      <tr>
	        <td>
	        	<p class="pull-right">E. & O.E</p>
	        	<br><br><br><br><p>Remarks:<br>
					Other fitting accessories 1 lot and a aluminium ladder</p>
	        </td>
	      </tr>
	    </tbody>
	  </table>
	  <table class="table table-bordered delivary height">
	    <tbody>
	      <tr>
	        <td>
	        	<p>Recd. in Good Condition</p>
	        </td>
	        <td>
	        	<p class="pull-right"><strong>for Webdesk Technologies</strong></p><br><br><br><br>
	        	<p class="pull-right">Authorised Signatory</p>
	        </td>
	      </tr>
	    </tbody>
	  </table>
	  <p class="text-center">This is a Computer Generated Document</p>
	</div>

</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>