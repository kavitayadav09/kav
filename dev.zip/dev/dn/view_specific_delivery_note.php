<?php 
	require_once '../config/config.php';
	session_start();

	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}

	$sql = "SELECT * from company_info";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$rows = mysqli_fetch_array($result);

	//echo ">>".$_GET['del_note_id'];
	if( isset( $_GET['del_note_id'] ) ){
		//echo ">>@1>>";

		$delNoteId = $_GET['del_note_id'];
		/*
		$deliveryNotesSql = "SELECT DN.*, C.cust_name, C.address FROM delivery_notes DN INNER JOIN customers C ON DN.cust_id = C.cust_id WHERE del_note_id = ?";
		//echo ">>@3>>".$deliveryNotesSql;
		

		$stmt = $conn->prepare( $deliveryNotesSql );
		$stmt->bind_param( "s", $delNoteId_Param );
		$delNoteId_Param = $delNoteId;
		*/
		$delivery_note_sql = "SELECT DN.*, C.cust_name, C.address FROM delivery_notes DN INNER JOIN customers C ON DN.cust_id = C.cust_id WHERE del_note_id='$delNoteId'";
        $delivery_note_result = mysqli_query($conn, $delivery_note_sql) or die("Error in Selecting " . mysqli_error($conn));
        while( $delivery_note_row = mysqli_fetch_array($delivery_note_result) ){

		/*if ( $stmt->execute() === TRUE ) {
			echo "string";
			$result = $stmt->get_result();
			echo ">>".$result->num_rows;

			if($result->num_rows > 0) {     
			    while ($data = $result->fetch_assoc()) 
			    {*/
			    	//echo ">>".$delivery_note_row['cust_name'];
			        $custName = $delivery_note_row['cust_name'];
			        $custAddress = $delivery_note_row['address'];
			        $deliveryNoteNo = $delivery_note_row['del_note_no'];
			        $deliveryNoteDate = $delivery_note_row['del_note_date'];
			        $buyerOrderNo = $delivery_note_row['buyer_order_no'];
			        $buyerOrderDate = $delivery_note_row['buyer_order_date'];
			        $destination = $delivery_note_row['des_destination'];
			        $remarks = $delivery_note_row['rem'];

			    }
			//}

			    

	$delivery_note_items_sql = "SELECT DNI.*, NP2.model_id, COUNT(DNI.model_id) as quantity FROM 
delivery_note_items DNI INNER JOIN 

(SELECT NP.product_id, NP.manufacturer_id, NP.model_id, NP.serial_no  
    FROM (SELECT P.product_id, P.manufacturer_id, P.model_id, P.serial_no 
          FROM products P WHERE P.sold='0' UNION 
          SELECT DP.product_id, DP.manufacturer_id, DP.model_id, DP.serial_no 
          FROM defective_products DP 
          WHERE DP.sold='0' AND DP.active='2' ) AS NP) AS NP2 
          
ON DNI.product_id = NP2.product_id WHERE DNI.del_note_id='$delNoteId' GROUP BY DNI.model_id";
        $delivery_note_items_result = mysqli_query($conn, $delivery_note_items_sql) or die("Error in Selecting " . mysqli_error($conn));

        $deliveryNoteItemData = array();

        while( $delivery_note_items_row = mysqli_fetch_array($delivery_note_items_result) ){

    		$model_id = $delivery_note_items_row['model_id'];
    		$model_name_sql = "SELECT model_name FROM models WHERE id='$model_id'";
            $model_name_result = mysqli_query($conn, $model_name_sql) or die("Error in Selecting " . mysqli_error($conn));
            $model_name_row = mysqli_fetch_array($model_name_result); 

    		$object = new stdClass();
    		
    		$object->product_name = $model_name_row['model_name'];
    		$object->quantity = $delivery_note_items_row['quantity'];
    		array_push( $deliveryNoteItemData, $object );
		}

			   /*
		$delivery_note_items_sql = "SELECT DNI.*, P.product_name, P.model_id, COUNT(DNI.model_id) as quantity FROM delivery_note_items DNI INNER JOIN products P ON DNI.product_id = P.product_id WHERE DNI.del_note_id='$delNoteId' GROUP BY DNI.model_id";
        $delivery_note_items_result = mysqli_query($conn, $delivery_note_items_sql) or die("Error in Selecting " . mysqli_error($conn));

        $deliveryNoteItemData = array();

        while( $delivery_note_items_row = mysqli_fetch_array($delivery_note_items_result) ){

    		$model_id = $delivery_note_items_row['model_id'];
    		$model_name_sql = "SELECT model_name FROM models WHERE id='$model_id'";
            $model_name_result = mysqli_query($conn, $model_name_sql) or die("Error in Selecting " . mysqli_error($conn));
            $model_name_row = mysqli_fetch_array($model_name_result); 

    		$object = new stdClass();
    		
    		$object->product_name = $model_name_row['model_name'];
    		$object->quantity = $delivery_note_items_row['quantity'];
    		array_push( $deliveryNoteItemData, $object );
		}

		$delivery_note_items_sql2 = "SELECT DNI.*, DP.model_id, COUNT(DNI.model_id) as quantity FROM delivery_note_items DNI INNER JOIN defective_products DP ON DNI.product_id = DP.product_id WHERE DNI.del_note_id='$delNoteId' GROUP BY DNI.model_id";
        $delivery_note_items_result2 = mysqli_query($conn, $delivery_note_items_sql2) or die("Error in Selecting " . mysqli_error($conn));

        while( $delivery_note_items_row2 = mysqli_fetch_array($delivery_note_items_result2) ){

    		$model_id = $delivery_note_items_row2['model_id'];
    		$model_name_sql = "SELECT model_name FROM models WHERE id='$model_id'";
            $model_name_result = mysqli_query($conn, $model_name_sql) or die("Error in Selecting " . mysqli_error($conn));
            $model_name_row = mysqli_fetch_array($model_name_result); 

    		$object = new stdClass();
    		
    		$object->product_name = $model_name_row['model_name'];
    		$object->quantity = $delivery_note_items_row2['quantity'];
    		array_push( $deliveryNoteItemData, $object );
		}
*/
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Webdesk Delivery Note</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  <style>
  	.delivary tr td, .delivary tr th{
  		padding:10px 0px !important;
  		border-color:#000000 !important;
  		border-width: 1px !important;
  		font-weight: normal;
  	}
  	.delivary{
  		margin-bottom: 0px;
  	}
  	.delivary tr td p, .delivary tr th p{
  		padding:0px 15px;
  	}
  	.delivary tr td p strong{
  		display: block;
  	}
  	.secondTable tr td p strong{
  		
  	}
  	.first tr td p, .first tr th p{
  		width:210px;
  	}
  	.first tr td img{
  		float: left;
  	}
  	.first tr td p{
  		float: left;
  	}
  	.first tr td{
  		width: 250px;
  	}
  	.borderNone{
  		border:0px !important;
  	}
  	.borderPaddingLeft{
  		border-left: 1px solid #000;
  		padding-left: 5px !important;
  	}
  	.height{
  		height: 80px;
  	}
  	.height tr td{
  		border-top:0px !important;
  	}
  	table{
  		border-color:#000000 !important;
  		margin-bottom: 0px !important
  	}
  	.center{
  		width:700px;
  		margin: 0 auto;
  	}
  </style>
</head>
<body>
	<div class="center">
	  <h2 class="text-center">Delivery Note</h2> 
	  <h5 class="text-center"><a href="#" onclick="javascript:window.print();">Print this page</a></h5>          
	  <table class="table table-bordered delivary" style='border-right:0px !important'>
	    <tbody>
	      <tr>
	        <td style='padding:0px !important;border-left:0px !important;border-right:0px !important;border-top:0px !important'><table class="table table first">
			    <tbody>
			      <tr>
			        <td class="borderNone" style='border-right:0px !important;border-left:0px !important'><img src="img/logh.png" alt=""><p><strong><?php echo $rows['company_name']?></strong><?php echo $rows['company_address']?></p>
					</td>
			      </tr>
			      <tr>
			        <td style='border-right:0px !important; border-bottom: 0px !important;border-left:0px !important'>
			        <p>Buyer:<br><strong><?php echo $custName ?></strong><?php echo $custAddress ?></p>
					</td>
			      </tr>
			    </tbody>
			  </table>
			  </td>
	        <td style='padding:0px !important;border-left:0px !important;border-right:0px !important;border-top:0px !important'>            
			  <table class="table">
			    <thead>
			      <tr style='padding:0px !important'>
			        <th ><p>Delivery Note No.<br>
						<strong><?php echo $deliveryNoteNo ?></strong></p>
					</th>
			        <th><p>Dated<br>
						<strong><?php 
							$date = date_create( $deliveryNoteDate );
							echo date_format( $date, "d/m/Y" ); ?></strong></p>
					</th>
			      </tr>
			    </thead>
			    <tbody>
			      <tr>
			        <td></td>
			        <td class="borderPaddingLeft"><p>Mode/Terms of Payment</p></td>
			      </tr>
			      <tr>
			        <td><p>Supplier's Ref.</p></td>
			        <td class="borderPaddingLeft"><p>Other Reference(s)</p></td>
			      </tr>
			      <tr>
			        <td><p>Buyer's Order No.</p><p><?php echo $buyerOrderNo ?></p></td>
			        <td class="borderPaddingLeft"><p>Dated</p><p><?php echo $buyerOrderDate ?></p></td>
			      </tr>
			      <tr>
			        <td><p>Despatch Document No.</p></td>
			        <td class="borderPaddingLeft"><p></p></td>
			      </tr>
			      <tr>
			        <td><p>Despatched through</p></td>
			        <td class="borderPaddingLeft"><p>Destination</p><p><?php echo $destination ?></p></td>
			      </tr>
			      <tr>
			        <td style='border-right: 0px !important;border-bottom: 0px !important'><p>Terms of Delivery</p></td>
			        <td style='border-left: 0px !important;border-top: 0px !important;   border-bottom: 0px !important'></td>
			      </tr>
			    </tbody>
			  </table>
			</td>
	      </tr>
	     
	    </tbody>
	  </table>

	  <table class="table table-bordered delivary secondTable" style='border-top:0px !important'>
	    <thead>
	      <tr>
	        <th><p>Sl no</p></th>
	        <th><p>Description of Goods</p></th>
	        <th><p>Quantity</p></th>
	        <th><p>Rate</p></th>
	        <th><p>per</p></th>
	        <th><p>Amount</p></th>
	      </tr>
	    </thead>
	    <tbody>

	      <tr>

	      	<td>
	      		<?php 
					
					$counter = 0;
					foreach ($deliveryNoteItemData as $item) 
					{	
				?>
					<p><strong><?php echo ++$counter ?></strong></p><br> 
				<?php
					}
				?>

			</td>

	        <td>
	        	<?php 
					
					foreach ($deliveryNoteItemData as $item) 
					{	
				?>
					<p><strong><?php echo $item->product_name ?></strong></p><br> 
				<?php
				
					}
				?>
	        </td>

	         <td>
	        	<?php 
					
					foreach ($deliveryNoteItemData as $item) 
					{	
				?>
					<p><strong><?php echo $item->quantity ?> NOS</strong></p><br> 
				<?php
				
					}
				?>
	        </td>

	        <td><p></p></td>
	        <td><p></p></td>
	        <td><p></p></td>
	      </tr>


	      <tr>
	      	<td><p></p></td>
	      	<td><p class="pull-right">Total</p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      	<td><p></p></td>
	      </tr>
	    </tbody>
	  </table>

	  <table class="table table-bordered delivary height">
	    <tbody>
	      <tr>
	        <td>
	        	<p class="pull-right">E. & O.E</p>
	        	<br><br><br><br><p>Remarks:<br><?php echo $remarks ?></p>
	        </td>
	      </tr>
	    </tbody>
	  </table>
	  <table class="table table-bordered delivary height">
	    <tbody>
	      <tr>
	        <td>
	        	<p>Recd. in Good Condition</p>
	        </td>
	        <td>
	        	<p class="pull-right"><strong><?php echo 'for'. ' ' . $rows['company_name']?></strong></p><br><br><br><br>
	        	<p class="pull-right">Authorised Signatory</p>
	        </td>
	      </tr>
	    </tbody>
	  </table>
	  <p class="text-center">This is a Computer Generated Document</p>
	</div>

</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>