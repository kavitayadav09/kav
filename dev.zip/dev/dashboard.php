<?php 
	include_once "includes/header.php";
?>

  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Welcome to Webdesk Inventory Management System</h1>
      

    </div>
 
  </div>
</div>

<?php
	include_once "includes/footer.php";

?>