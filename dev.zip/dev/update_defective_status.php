<?php
require_once 'config/config.php';

session_start();
if( isset($_SESSION['user_id']) ){
	//proceed
} else {
	header( 'Location:logout.php' );
}

if( !isset( $_SESSION['type'] )){
	//show nothing
	header( 'Location:logout.php' );
} else {
	if( $_SESSION['type'] == 1 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
}

$p_id=$_POST['pid'];
$status=$_POST['a'];
$sql3 = "UPDATE defective_products SET active='$status' WHERE product_id='$p_id'";
$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
echo 'success';

?>