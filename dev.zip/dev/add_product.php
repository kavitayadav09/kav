<?php
include_once "includes/header.php";
   $msg = "";
	if(isset($_POST['submit'])){
	if( isset( $_POST['serial_no'] ) ){
		//$product_list = explode( PHP_EOL, $_POST['serial_no'] );
		$product_trim_list = array_map( 'trim', array_filter( explode( PHP_EOL, $_POST['serial_no'] ) ) );
		$product_filter_list = array_filter( $product_trim_list, function($value) { return $value !== ''; } );
		$product_list_unique = array_unique( $product_filter_list );
		$quantity = 1;

	} else {
		//Product Item without Model ID
		$product_list_unique = array();
		$quantity = $_POST['quantity_ns'];
	}
	
	//print_r($product_list_unique);
	//echo "string";
	//exit();

	if( isset( $_POST['product_name'] ) ){
		$name = $_POST['product_name'];
	}else{
		$name = NULL;
	}

	$model_id = $_POST['models_cb'];
	$manufacturer_id = $_POST['m_id'];

	//print_r($product_list_unique);

	if( count( $product_list_unique ) > 0 ){
		//Has SERIAL NO.
		foreach ( $product_list_unique as $value ) {
			//$slno = $product_list_unique[$i];
			
			//echo ">>".$value."<<";
			$slno = $value;

			$product_check_sql = "SELECT * FROM products WHERE serial_no='$slno' AND model_id='$model_id'";
			$product_check_result = mysqli_query($conn, $product_check_sql) or die("Error in Selecting " . mysqli_error($conn));
			$product_check_row = mysqli_fetch_array( $product_check_result );

			if( isset( $product_check_row['product_id'] ) ){
				//exists
				//do not add to system
			} else {
				$sql = "INSERT INTO products ( product_name, serial_no, quantity, manufacturer_id, model_id) VALUES( '$name', '$slno', '1', '$manufacturer_id', '$model_id')";
				if ($conn->query($sql) === TRUE) {
					$msg = "New record created successfully";
				} else {
					$msg = "Error: " . $sql . "<br>" . $conn->error;
				}
			}
		}

	} else {
		for( $i = 0; $i < $quantity; $i++ ){
			$slno = 0;
			$sql = "INSERT INTO products ( product_name, serial_no, quantity, manufacturer_id, model_id) VALUES( '$name', '$slno', '1', '$manufacturer_id', '$model_id')";
			if ($conn->query($sql) === TRUE) {
				$msg = "New record created successfully";
			} else {
				$msg = "Error: " . $sql . "<br>" . $conn->error;
			}
		}
	}
	
	$conn->close();
	header("Location:view_product.php");

	echo $msg;
}

?> 
 

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add Product Information</h1>
	  
         <form action="" method="post" class="form-horizontal customform" onsubmit="return validateForm();">
		   
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
			
			<select name="m_id" class="m_id form-control" id="m_id" required>
			<option value="0">Select</option>
			<?php 
				$sql2 = "SELECT * FROM manufacturers";
				$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));	
				while($row2=mysqli_fetch_array($result2)){	
			?>
				<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			<?php
				}
			?>
			</select>
		</div>
	</div>

		<div class="form-group">
			<label class="control-label col-sm-3" for="pwd">Model Name:</label>
			<div class="col-sm-8">
				<select name="models_cb" id="models_cb" class="form-control" onchange="checkForSerializedModel();">
				<option value="0">Select</option>
				</select>
			</div>
		</div>

		<div class="form-group">
			<label class="control-label col-sm-3" for="email">Model Description:</label>
			<div class="col-sm-8">
			  <input type="text" class="form-control" id="model_desc" placeholder="" readonly>
			</div>
		</div>

		<div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Quantity:</label>
            <div class="col-sm-8">
              <input type="number" min="0" max="500" name="quantity_ns" onkeydown="return isNumberKey(event);" class="form-control" id="quantity_ns" placeholder="Enter Quantity" value="0" required>
            </div>
          </div>
          
         <div class="form-group" hidden="true">
            <label class="control-label col-sm-3" for="email">Product Name:</label>
            <div class="col-sm-8">
              <input type="text" name="product_name" class="form-control" id="product_name" placeholder="Enter Product Name">
            </div>
          </div>

		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Serial No:</label>
            <div class="col-sm-8">
              <textarea name="serial_no" class="form-control" id="serial_no" placeholder="Enter Serial No.s"></textarea>
            </div>
          </div>
		  
		  
		
		  
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Add</button>
            <?php 
              }
            ?>
			  <a href="view_product.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
</div>
</div>
<?php
	include_once "includes/footer.php";

?>
<script>


$(document).ready(function(){
	
    $("#serial_no").focus();

    $("#quantity_ns").change(function(){
		var qty = parseInt( $(this).val() );
		if( qty > 0 ){
			$("#serial_no").val( "" );
			$("#serial_no").attr( 'disabled', true );

		} else {
			if( $('#models_cb').attr( 'disabled' ) == 'disabled' ){
				$("#serial_no").attr( 'disabled', true );

			} else {
				$("#serial_no").attr( 'disabled', false );
			}
		}
    });

    $(".m_id").change(function(){
		var b = $(this).val()
        updateModel(b);
    });
	  
});

function checkForSerializedModel()
{
	var serialized = $('#models_cb option:selected').attr('data-serialized');
	if( serialized == '0' ){
		$("#quantity_ns").attr( 'disabled', true );
		$("#serial_no").attr( 'disabled', false );
	} else {
		$("#quantity_ns").attr( 'disabled', false );
		$("#serial_no").attr( 'disabled', true );
	}
	var desc = unescape( $('#models_cb option:selected').attr('data-desc') );
	if( desc == null || desc == 'null' || desc == undefined || desc == 'undefined' ){
		desc = "";
	}
	
	$("#model_desc").val( desc );
}

function isNumberKey(evt) 
{
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if ((charCode < 48 || charCode > 57))
        return false;

    return true;
}

function updateModel(a) {
    //alert(a);
	
	var data = {
        mid: a
    };
	
	$('#models_cb').empty();
	$('#models_cb').append( '<option value="0">Select</option>' );
	
    try{
      $.ajax({
          type: "POST",
          url: "get_model_by_id.php",
          data: data,
          success: function(data){
			var dataObj = JSON.parse(data);
			//alert(data);
			if( dataObj.length > 0 ){
				$('#models_cb').attr( 'disabled', false );
				//$("#serial_no").attr( 'disabled', false );

				$.each( dataObj, function(key,value) {
					var desc = value.desc;
				  $('#models_cb').append( '<option value="'+value.id+'" data-serialized="'+value.serialized+'" data-desc="'+escape(desc)+'"">'+value.name+'</option>' );
				  //alert(escape(desc));
				}); 
			} else {
				if( $('#m_id').val() == 0 ){
					$('#models_cb').attr( 'disabled', false );
					//$("#serial_no").attr( 'disabled', false );
					$("#quantity_ns").val(0);
				} else {
					$('#models_cb').attr( 'disabled', true );
					//$("#serial_no").attr( 'disabled', true );
				}
			}
          },
          fail: function(e){
            alert("Please try after sometime");
          }
      });
    } catch(e){
      
    }
  }

function validateForm()
{
	if( $('#serial_no').attr( 'disabled' ) != 'disabled' ) {
		if( $('#serial_no').val() == "" ){
			alert( 'Please enter serial no.' );
			return false;
		}
	}

	if( $('#m_id').val() == "" ){
		alert( 'Please select manufacturer' );
		return false;
	}

	if( $('#models_cb').attr( 'disabled' ) != 'disabled' ) {
		if( $('#models_cb').val() == 0 ){
			alert( 'Please select model' );
			return false;
		}
	}

	return true;
}
</script>