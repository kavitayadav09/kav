<?php
include_once "includes/header.php";

if( isset($_GET['pid']) ){
	$product_id = $_GET['pid'];

	$sql="SELECT * FROM defective_products WHERE product_id='$product_id'";

	$result = mysqli_query($conn,$sql);

   	$row = mysqli_fetch_array($result);   

} else {
	header("location:view_defective_items.php");
	exit();
}
   
if(isset($_POST['submit'])){
	//$slno = $_POST['serial_no'];
	$active = $_POST['active_id'];

	$sql="UPDATE defective_products SET active='$active' WHERE product_id='$product_id'";

	if ($conn->query($sql) === TRUE) {
	    echo "Updated successfully";
	    $conn->close();
		header("Location:view_defective_items.php");
		exit();
	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}

?> 
 
<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Defective Product Information</h1>
 
         <form action="" method="post" class="form-horizontal customform">
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Serial No:</label>
            <div class="col-sm-9">
              <input type="text" name="serial_no" value="<?php 
              	if( $row['serial_no'] == 0) { 
              		echo ""; 
              	}else { 
              		echo $row['serial_no']; 
              	} ?>" class="form-control" autocomplete="off" id="serial_no" placeholder="Enter Serial no" <?php
              	if( $row['serial_no'] != 0){ 
              		echo "readonly";
              	}?> >
			   
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Active:</label>
			<div class="col-sm-9">
		
				<select name="active_id" id="active_id" class="form-control" required>
				<option value="">Select</option>
					<option value="0">NO</option>
					<option value="1">YES</option>
				</select>
				<?php
					echo '<script>jQuery("#active_id").val("'.$row['active'].'");</script>';
				  ?>  		  	  
			</div>	
		</div>  
 		  
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Update</button>
            <?php 
              }
            ?>
			  <a href="display_product.php?maid=<?php echo $manufacturer_id;?>&moid=<?php echo $model_id;?>" type="button" class="btn btn-success backproduct">Back</a>
            </div>
          </div>
        </form> 
</div>
</div>
 
<?php
	include_once "includes/footer.php";

?>

