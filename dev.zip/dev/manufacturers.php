<?php 
	include_once "includes/header.php";
	
	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
	

  	$per_page_limit = 50;
	$total_pages = 0;
	$page = 0;
	$offset = 0;
		
	$sql = "SELECT count(*) FROM manufacturers ";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );

	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:manufacturers.php");
	} 	
?>
  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Manufacturers Management</h1>
     <ul class="pagination">
        <?php
        	if( $total_pages > 1 ){
        		for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          			<li><a href="manufacturers.php?page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
          		}	
          	}
        ?>
      </ul>
      <div class="clear"></div>
      <a href="add_manufacturers.php" type="button" class="btn btn-success addUser">Add Manufacturer</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>
           
            <!--th>Manufacturer ID</th-->
            <th>Manufacturer Name</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          
<?php        
//$id=$_POST['m_id'];
//$name=$_POST['m_name'];

$sql="SELECT m_id, m_name FROM manufacturers LIMIT $offset, $per_page_limit";
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	while($row=mysqli_fetch_array($result)){  
?>
        <tr>
		  <!--td>< ?php echo $row['m_id']; ?></td-->
          <td><?php echo $row['m_name']; ?></td>
		  <td><a href="update_manufacturers.php?edit=<?php echo $row['m_id'];?>">Edit</a>
		  <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
             | <a href="#" class='abc' data-link="delete.php?delete=<?php echo $row['m_id'];?>">Delete</a>
            <?php 
              }
            ?></td>
		</tr>
		
<?php
	}
?>
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>

$(document).ready(function(){
    $(".abc").click(function(){
		
		var location = $(this).attr("data-link");
        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
	
			}
		else{
				return false;
		}
    });
});
</script>

<?php
	include_once "includes/footer.php";

?>