<?php

  require_once "includes/header.php";
  
  if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
    //admin
  } else {
    header( 'Location:logout.php' );
  }
?> 

<link rel="stylesheet" href="css/jquery-ui.css">
<script src="script/jquery-ui.min.js"></script>

<?php
  require_once "includes/sides.php";
?>

<div class="col-sm-10 text-center user">    
  
    <div class="col-sm-8 text-left marginAuto AddUser">

      <h1>Add Delivery Note Information</h1>
	  
      <form action="" method="post" class="form-horizontal">
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" for="email">* Delivery Note No. :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" name="deliveryNoteNo" id="deliveryNoteNo" placeholder="Enter Delivery Note No." readonly> <!--disabled-->
          </div>
      </div>
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Delivery Note Date :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" name="deliveryNoteDate" id="deliveryNoteDate" placeholder="Enter Delivery Note Date">
          </div>
      </div>
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Buyer Name :</label>
          <div class="col-sm-8">
              <select name="buyer_name" class="buyer_name" id="buyer_name" onchange="changeBuyer();">
                <option value="0">Select</option>
                  <?php 
                    $sql2 = "SELECT * FROM customers";
                    $result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
                    while($row2=mysqli_fetch_array($result2)){ 
                  ?>
                      <option address-value="<?php echo $row2[4];?>" value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
                  <?php
                    }
                  ?>
              </select>
          </div>
      </div>
		  
      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Buyer Address :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" id="buyerAddress" placeholder="Enter Buyer Address" readonly ></textarea>
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Buyer Order No. :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" name="buyerOrderNo" id="buyerOrderNo" placeholder="Enter Buyer Order No.">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Buyer Order Date :</label>
          <div class="col-sm-8" id='datetimepicker2'>
              <input type="text" class="form-control" name="buyerOrderDate" id="buyerOrderDate" placeholder="Enter Buyer Order Date">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Despatch Destination :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" name="despatchDestination" id="despatchDestination" placeholder="Enter Despatch Destination">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Product Serial Nos. :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" name="serial_no" id="serial_no" placeholder="Enter Product Serial Nos." ></textarea>
              <p>Note: Place Serial No.s in each line.</p>
          </div>
      </div>


       <table class="table table-hover userDashTable rwd-table newtable data-entry-module">
        <tbody>
          <tr>
            <td>
              <div class="form-group">
              </div>
            </td>
            <td> 
              <div class="form-group">
                <label class="control-label col-sm-6" for="pwd">Products :</label>
                <div class="col-sm-10">
                  <select name="product_item" class="product_item">
                    <option value="0">Select</option>
                      <?php 
                      $sql3 = "SELECT P.product_id, P.quantity, P.manufacturer_id, P.model_id, M.id, M.model_name, COUNT(P.model_id) as qyt FROM models M INNER JOIN products P ON M.manufacturer_id = P.manufacturer_id WHERE P.serial_no='0' AND P.sold='0' GROUP BY P.model_id;";
                      $result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));

                      while($row3=mysqli_fetch_array($result3))
                      { 
                      ?>
                        <option value="<?php echo $row3[0];?>" manufacturer_id="<?php echo $row3['manufacturer_id'];?>" model_id="<?php echo $row3['model_id'];?>" available-stock="<?php echo $row3['qyt'];?>"><?php echo $row3['model_name'] . ' (' . $row3['qyt'] . ')' ?></option>
                      <?php
                      }
                    ?>
                  </select>
                </div>
            </div>
            </td>
            <td>
              <div class="form-group">
                <label class="control-label col-sm-7" for="pwd">Quantity :</label>
                <div class="col-sm-6">
                  <input type="number" min="1" max="100" name="quantity" class="quantity" id="" value="1">
                </div>
              </div>
            </td>
            <td>
              <div class="form-group">
                <button type="button" name="add-item" class="btn btn-success add-item" >Add Item</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <table class="table table-hover userDashTable rwd-table newtable item-container">
        <thead>
          <tr>
            <th>Sl No</th>
            <th>Description of Goods</th>
            <th>Quantity</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Remarks :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" name="remarks" id="remarks" placeholder="Enter your remarks"></textarea>
          </div>
      </div>

		  <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Create Delivery Note</button>
            <?php 
              }
            ?>
			     <a href="view_delivery_note.php" type="button" class="btn btn-success back">Back</a>
        </div>
      </div>
         
    </form> 
  </div>
</div>

<div class="col-sm-12"> 
<?php
	include_once "includes/footer.php";
?>
</div>


<script>

$(document).ready(function()
{   
    var unique_slno_list = [];

    var sl = 0; 

    setDeliveryNoteNumber();

    $( "#deliveryNoteDate" ).datepicker({dateFormat:"yy/mm/dd"}).datepicker("setDate",new Date());

    $( "#deliveryNoteDate" ).datepicker({ 
        onClose: function() 
        {
            //valid();
        }
    });

    //$( "#buyerOrderDate" ).datepicker({dateFormat:"yy/mm/dd"}).datepicker("setDate", new Date());

    $( "#buyerOrderDate" ).datepicker({ 
        dateFormat: "yy/mm/dd",
        onClose: function() 
        {
            //valid();
        }
    });

    // add product item into delivery note
    $(".add-item").click(function()
    {
        var product_id = $(".product_item").val();

        if ( product_id < 1 ){
           alert ( "Please select item" );
        } else {
          sl++; 
          var product_item = $(".product_item option:selected").text();
          var quantity = parseInt( $(".quantity").val() );
          var availableQty = parseInt( $(".product_item option:selected").attr('available-stock') );
          var manufacturer_id = $(".product_item option:selected").attr('manufacturer_id');
          var model_id = $(".product_item option:selected").attr('model_id');
          
          if( quantity > availableQty ){
            return alert( 'You cannot add items more than available stock.' );
          }
          
          if( quantity > ( availableQty - getItemCount( product_id ) ) ){
            return alert( 'You cannot add items more than available stock.' );
          } 

          var rowData = "<tr><td><div class='form-group'>" + sl + "</div></td><td data-value='" + product_id + "' data-model='" + product_item + "' data-manufacturer_id='" + manufacturer_id + "' data-model_id='" + model_id + "' ><div class='form-group'><div class='col-sm-10'>" + product_item + "</div></div></td><td><div class='form-group'><div class='col-sm-6'>" + quantity + "</div></div></td><td><div class='form-group'><button type = 'button' name='remove-item' class='btn btn-success remove-item'>Remove Item</button>";

          $(".item-container").append(rowData);

          // initlize data
          var opt_sel = $('.product_item');
          opt_sel.val(0);

          var quantity = $(".quantity");
          quantity.val(1);
        }
    });

    // remove product item from delivery note
    $(document).on("click", ".remove-item" , function() 
    {
         //$(this).parents("tr").remove();

        var r = confirm("Are you sure ?");

        if (r == true) {
            $(this).parents("tr").remove();
        } 
    });

    $('form').on('submit', function( event ) 
    {
        event.preventDefault();
        // form validation 
        if ( isFormValidationOk() ){

            var deliveryNoteItemData = [],
            keys = [ '', 'productId', 'quantity', '' ];

            $(".item-container").find('tr:gt(0)').each(function( i, row ) {
                var oRow = {};

                $( row ).find( 'td' ).each( function( j, cell ) {
                    if ( j === 1 ){
                       oRow[ keys[ j ] ] = $( this ).attr('data-value');

                      oRow[ keys[ j ] ] = $( this ).attr('data-value');
                      oRow[ 'manufacturerId' ] = $( this ).attr('data-manufacturer_id');
                      oRow[ 'modelId' ] = $( this ).attr('data-model_id');
                      oRow[ 'serialNo' ] = null;
                    }

                    if ( j === 2 ){
                      oRow[ keys[ j ] ] = $( cell ).text();
                    }
                });

                deliveryNoteItemData.push( oRow );
            });

            var slno_list = [];

           $.each($('#serial_no').val().split(/\n/), function(i, line){
                if(line){
                    slno_list.push(line);
                } 
            });

           unique_slno_list = slno_list.filter(function(itm, i, a) {
              return i == slno_list.indexOf(itm);
            });

            var row;
            for( var m=0; m<unique_slno_list.length; m++ ){
              row = {};
              row['serialNo'] = unique_slno_list[m];
              deliveryNoteItemData.push( row );
            }
            
            //alert( JSON.stringify( deliveryNoteItemData ) );
            //return;

            var deliveryNoteData = { "deliveryNoteNo" : $('#deliveryNoteNo').val(), 'deliveryNoteDate' : $('#deliveryNoteDate').val(), 'buyerId' : $('#buyer_name').val(), 'buyerOrderNo' : $('#buyerOrderNo').val(), 'buyerOrderDate' : $('#buyerOrderDate').val(), 'despatchDestination' : $('#despatchDestination').val(), 'remarks' : $('#remarks').val() };

            //alert( JSON.stringify( deliveryNoteData ) );

            postDeliveryNoteData( JSON.stringify( deliveryNoteData ), JSON.stringify( deliveryNoteItemData ) );
        }
    })

});

function getItemCount( item )
{
  var count = 0;
  var productId = "";
  //alert(item);
  keys = [ '', 'productId', 'quantity', '' ];

  $(".item-container").find('tr:gt(0)').each(function( i, row ) 
  {
      $( row ).find( 'td' ).each( function( j, cell ) {
          if ( j === 1 ){
            productId = $( this ).attr('data-value');
          }

          if( productId == "" ){

          } else {
            if ( productId == item && j === 2 ){
              count += parseInt( $( cell ).text() );
            }
          }
      });
  });
  return count;
}

function changeBuyer()
{
  //$("#buyer_name").change(function() {
  var address = $("#buyer_name option:selected").attr('address-value');
  $('#buyerAddress').val( address );
  //});
}

function isFormValidationOk()
{
   var deliveryNoteItemCount = 0;
   
   //var slno = $('#serial_no').val();
   //alert(slno);
   var slno_list = [];

   $.each($('#serial_no').val().split(/\n/), function(i, line){
        if(line){
            slno_list.push(line);
        } 
    });

   unique_slno_list = slno_list.filter(function(itm, i, a) {
      return i == slno_list.indexOf(itm);
    });
   //alert("@1:"+unique_slno_list.length);

    $(".item-container").find('tr:gt(0)').each(function( i, row ) 
   {
      deliveryNoteItemCount = i + 1;
   });

   var deliveryNoteDate = $("#deliveryNoteDate").val();
   var buyerName = $(".buyer_name option:selected").text(); 

   var deliveryNoteDateValid = false;
   var buyerNameValid = false;
   var deliveryNoteItemValid = false;
   var result;

   if ( deliveryNoteDate != "" ){

      if (Date.parse(deliveryNoteDate)) {

         deliveryNoteDateValid = true;

      } else {

         alert ( "Invalid Delivery Note Date" );
         return false;

      }

   } else {

      alert ( "Delivery Note Date is required" );
      return false;
   }

   if( $('#buyerOrderDate').val() != "" ){
      if( $('#buyerOrderNo').val() == "" ){
        alert( 'Buyer Order No. cannot be blank.' );
        return false;
      }
   }

   if ( buyerName != "Select" ){

      buyerNameValid = true;

   } else {

      alert ( "Buyer Name is required. Please select from dropdown menu" );
      return false;
   }

   if ( deliveryNoteItemCount > 0 || unique_slno_list.length  > 0 ){

      deliveryNoteItemValid = true;

   } else {

      alert ( "Minimum 1 product item is required" );
      return false;
   }

   if ( deliveryNoteDateValid && buyerNameValid && deliveryNoteItemValid ){

    result = true;

   } else {

    result = false

   }

   return result;
}

function setDeliveryNoteNumber()
{
    $.ajax({
      url: 'get_data.php',
      type: 'post',
      data: { "function" : "getDeliveryNoteNumber" },
        success: function(response) 
        { 
          $('#deliveryNoteNo').val( response );
        },
        fail: function(e)
        {
          alert("Please try after sometime");
        }
    });
}

function postDeliveryNoteData( deliveryNoteData, deliveryNoteItemData )
{
    $.ajax({
      url: 'get_data.php',
      type: 'post',
      data: { "function" : "postDeliveryNoteData", "param" : deliveryNoteData, "param2" : deliveryNoteItemData },
        success: function(response) 
        { 
          if( response == 'success' ){
            location.href = "view_delivery_note.php";
          } else {
            alert(response);
          }         
        },
        fail: function(e)
        {
            alert("Please try after sometime : " + e );
        }
    });
}

</script>