<?php 
	include_once "includes/header.php";
	
	$per_page_limit = 50;
	$total_pages = 0;
	$page = 0;
	$offset = 0;
		
	$sql = "SELECT count(*) FROM defective_products WHERE sold='0'";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );

	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:view_defective_product.php");
	} 
	  
	
?>

  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Defective Product Management</h1>
       <ul class="pagination">
        <?php
        	if( $total_pages > 1 ) {
          		for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          			<li><a href="view_defective_product.php?page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
        		}
          	}
        ?>
      </ul>
      <div class="clear"></div>
      <a href="add_defective_product.php" type="button" class="btn btn-success addProduct">Add Defective Product</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>
            <th>Model</th>
			<th>Manufacturer</th>
			<th>Serial No.</th>
			<th>Entry Date</th>
			<th>Status</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          
<?php        

$sql1="SELECT * FROM defective_products WHERE sold='0' AND active <> 2 LIMIT $offset, $per_page_limit";
$result = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));

	while($row=mysqli_fetch_array($result))
    { 

?>
 <tr>
          <td><?php 
			$mo_id = $row['model_id']; 
			$sql3="SELECT model_name FROM models WHERE id='$mo_id'";
			$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
			while($row3=mysqli_fetch_array($result3)){
				echo $row3[0];
			}
		  
		  ?></td>
		  
		  <td><?php 
			$mid = $row['manufacturer_id']; 
			$sql2="SELECT m_name FROM manufacturers WHERE m_id='$mid'";
			$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
			while($row2=mysqli_fetch_array($result2))
			{
				echo $row2[0];
			}
		  
		  ?></td>
		  
		  <td><?php 
				echo $row['serial_no']; 
			?></td>

		<td><?php 
				$date = date_create( $row['entry_date'] );
				echo date_format( $date, "d/m/Y" ); 
			?></td>
		  
		  <td><?php 
			  if( $row['active'] == 0 ){
					echo 'Defective'; 
			?>
				<br><button type="button" name="add-item" class="btn btn-success add-item" onclick="updateStatus(<?php echo $row['product_id'];?>, 1);" >Send for Repair</button>
			<?php
			  } else if( $row['active'] == 1 ){
			  	echo 'Out for Repair'; 
			  ?>
				<br><button type="button" name="add-item" class="btn btn-success add-item" onclick="updateStatus(<?php echo $row['product_id'];?>, 2);" >Mark Repaired</button>
			<?php
			  } else {
			  	echo 'Ready for Sale'; 
			  }
			?></td>

		  <td><?php 
		  	if( $_SESSION['type'] == 1 ){
			?><a href="#" class='delete_btn' data-link="delete_defective_product.php?pid=<?php echo $row['product_id'];?>">Delete</a>
			<?php
			}
		  ?></td>
		</tr>
		
<?php
	}
?>  
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>

$(document).ready(function(){
    $(".delete_btn").click(function(){
		
		var location = $(this).attr("data-link");
        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
		} else {
			return false;
		}
    });
});

function updateStatus( pid, active )
{
	var data = {
        pid: pid,
        a: active
    };

	$.ajax({
	  type: "POST",
	  url: "update_defective_status.php",
	  data: data,
	  success: function(data){
		//alert(data);
		window.location.href = "view_defective_items.php";	
	  },
	  fail: function(e){
	    alert("Please try after sometime");
	  }
	});
}

</script>

<?php
	include_once "includes/footer.php";

?>