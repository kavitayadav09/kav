<?php

require_once "includes/header.php";

if( isset( $_GET['edit'] ) ){
  $noteid = $_GET['edit'];

  $sql = "SELECT * FROM delivery_notes WHERE del_note_id='$noteid'";
  $result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
  $row = mysqli_fetch_array( $result );

}

function gotoView()
{
  header("Location:view_delivery_note.php");
}

?> 
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="script/jquery-ui.min.js"></script>

<?php
  require_once "includes/sides.php";
?>

<div class="col-sm-10 text-center user">    
  
    <div class="col-sm-8 text-left marginAuto AddUser">

      <h1>Update Delivery Note Information</h1>
	  
      <form action="" method="post" class="form-horizontal" onsubmit="return isFormValidationOk();">
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" >* Delivery Note No. :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" id="deliveryNoteNo" placeholder="Enter Delivery Note No." readonly value="<?php echo $row['del_note_no'];?>"> <!--disabled-->
          </div>
      </div>
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Delivery Note Date :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" id="deliveryNoteDate" placeholder="Enter Delivery Note Date" value="<?php echo $row['del_note_date'];?>">
          </div>
      </div>
		  
		  <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Buyer Name :</label>
          <div class="col-sm-8">
              <select name="buyer_name" class="buyer_name" id="buyer_name" onchange="changeBuyer();">
                <option value="0">Select</option>
                  <?php 
                    $sql2 = "SELECT * FROM customers";
                    $result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
                    while($row2=mysqli_fetch_array($result2)){ 
                  ?>
                      <option address-value="<?php echo $row2[4];?>" value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
                  <?php
                    }
                  ?>
              </select>

          </div>
      </div>
		  
      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">* Buyer Address :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" id="buyerAddress" placeholder="Enter Buyer Address" ></textarea>

              <?php
                $cust_add_sql = "SELECT address FROM customers WHERE cust_id='".$row['cust_id']."'";
                $cust_add_result = mysqli_query( $conn, $cust_add_sql ) or die("Error in Selecting " . mysqli_error($conn));
                $cust_add_row = mysqli_fetch_array( $cust_add_result );

                echo "<script>";
                echo "$('#buyer_name').val('".$row['cust_id']."');";
                echo "$('#buyerAddress').val('".$cust_add_row['address']."');";
                echo "</script>";
              ?>
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Buyer Order No. :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" id="buyerOrderNo" placeholder="Enter Buyer Order No." value="<?php echo $row['buyer_order_no'];?>">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Buyer Order Date :</label>
          <div class="col-sm-8" id='datetimepicker2'>
              <input type="text" class="form-control" id="buyerOrderDate" placeholder="Enter Buyer Order Date" value="<?php echo $row['buyer_order_date'];?>">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Despatch Destination :</label>
          <div class="col-sm-8">
              <input type="text" class="form-control" id="despatchDestination" placeholder="Enter Despatch Destination" value="<?php echo $row['buyer_order_date'];?>">
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Serial Nos. :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" name="serial_no" id="serial_no" placeholder="Enter Product Serial Nos." ><?php
              $delivery_item_sql = "SELECT * FROM delivery_note_items WHERE del_note_id='".$row['del_note_id']."'";
              $delivery_item_result = mysqli_query( $conn, $delivery_item_sql ) or die("Error in Selecting " . mysqli_error($conn));
              while( $delivery_item_row = mysqli_fetch_array( $delivery_item_result ) ){
                echo $delivery_item_row['product_id']."\n";
              }

              ?></textarea>
              <p>Note: Place Serial No.s in each line.</p>
          </div>
      </div>

      <div class="form-group">
          <label class="control-label col-sm-3" for="pwd">Remarks :</label>
          <div class="col-sm-8">
              <textarea class="form-control" rows="5" id="remarks" placeholder="Enter your remarks" ><?php echo $row['rem'];?></textarea>
          </div>
      </div>

		  <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" name="submit" class="btn btn-success" >Update</button>
			     <a href="view_delivery_note.php" type="button" class="btn btn-success back">Back</a>
        </div>
      </div>
         
    </form> 
  </div>
</div>

<div class="col-sm-12"> 
<?php
	include_once "includes/footer.php";
?>
</div>


<script>

$(document).ready(function()
{
    $( "#deliveryNoteDate" ).datepicker({dateFormat:"yy/mm/dd"});

    $( "#deliveryNoteDate" ).datepicker({ 
        onClose: function() {}
    });

    $( "#buyerOrderDate" ).datepicker({ 
        dateFormat: "yy/mm/dd",
        onClose: function() {}
    });

    // add product item into delivery note
    /*$(".add-item").click(function(){

        var product_id = $(".product_item").val();
        //alert(">>>"+product_id);
        if ( product_id < 1 ){
           alert ( "Please select item" );
        } else {
          sl++; 
          var product_item = $(".product_item option:selected").text();
          var quantity = $(".quantity").val();
          var availableQty = $(".product_item option:selected").attr('available-stock');
          
          if( quantity > availableQty ){
            return alert( 'You cannot add items more than available stock.' );
          }

          if( quantity > ( availableQty - getItemCount( product_id ) ) ){
            return alert( 'You cannot add items more than available stock.' );
          } 

          var rowData = "<tr><td><div class='form-group'>" + sl + "</div></td><td data-value='" + product_id + "' data-model='" + product_item + "'><div class='form-group'><div class='col-sm-10'>" + product_item + "</div></div></td><td><div class='form-group'><div class='col-sm-6'>" + quantity + "</div></div></td><td><div class='form-group'><button type = 'button' name='remove-item' class='btn btn-success remove-item'>Remove Item</button>";

          $(".item-container").append(rowData);

          // initlize data
          var opt_sel = $('.product_item');
          opt_sel.val(0);

          var quantity = $(".quantity");
          quantity.val(1);
        }
    });

    // remove product item from delivery note
    $(document).on("click", ".remove-item" , function() 
    {
         //$(this).parents("tr").remove();

        var r = confirm("Are you sure ?");

        if (r == true) {
            $(this).parents("tr").remove();
        } 
    });


    $('form').on('submit', function( event ) 
    {
        event.preventDefault();
      
        // form validation 
        if ( isFormValidationOk() ){

            var deliveryNoteItemData = [],
            keys = [ '', 'productId', 'quantity', '' ];

            $(".item-container").find('tr:gt(0)').each(function( i, row ) 
            {
                var oRow = {};

                $( row ).find( 'td' ).each( function( j, cell ) 
                {
                    

                    if ( j === 1 ){
                      oRow[ keys[ j ] ] = $( this ).attr('data-value');
                    }

                    if ( j === 2 ){
                      oRow[ keys[ j ] ] = $( cell ).text();
                    }
                });

                deliveryNoteItemData.push( oRow );
            });

            //alert( JSON.stringify( deliveryNoteItemData ) );

            var deliveryNoteData = { "deliveryNoteNo" : $('#deliveryNoteNo').val(), 'deliveryNoteDate' : $('#deliveryNoteDate').val(), 'buyerId' : $('#buyer_name').val(), 'buyerOrderNo' : $('#buyerOrderNo').val(), 'buyerOrderDate' : $('#buyerOrderDate').val(), 'despatchDestination' : $('#despatchDestination').val(), 'remarks' : $('#remarks').val() };

            //alert( JSON.stringify( deliveryNoteData ) );

            postDeliveryNoteData( JSON.stringify( deliveryNoteData ), JSON.stringify( deliveryNoteItemData ) );
        }
    })*/

});
/*
function getItemCount( item )
{
  var count = 0;
  var productId = "";
  //alert(item);
  keys = [ '', 'productId', 'quantity', '' ];

  $(".item-container").find('tr:gt(0)').each(function( i, row ) 
  {
      $( row ).find( 'td' ).each( function( j, cell ) {
          if ( j === 1 ){
            productId = $( this ).attr('data-value');
          }

          if( productId == "" ){

          } else {
            if ( productId == item && j === 2 ){
              count += $( cell ).text();
            }
          }
      });
  });
  return count;
}*/

function changeBuyer()
{
  //$("#buyer_name").change(function() {
  var address = $("#buyer_name option:selected").attr('address-value');
  $('#buyerAddress').val( address );
  //});
}

function isFormValidationOk()
{
   var deliveryNoteItemCount = 0;
   slno_list = [];
   $.each($('#serial_no').val().split(/\n/), function(i, line){
        if(line){
            slno_list.push(line);
        } 
    });

    var unique_slno_list = slno_list.filter(function(itm, i, a) {
      return i == slno_list.indexOf(itm);
    });
  
  deliveryNoteItemCount = unique_slno_list.length;
  //alert(deliveryNoteItemCount);

   var deliveryNoteDate = $("#deliveryNoteDate").val();
   var buyerName = $(".buyer_name option:selected").text(); 

   var deliveryNoteDateValid = false;
   var buyerNameValid = false;
   var deliveryNoteItemValid = false;
   var result;

   if ( deliveryNoteDate != "" ){

      if (Date.parse(deliveryNoteDate)) {

         deliveryNoteDateValid = true;

      } else {

         alert ( "Invalid Delivery Note Date" );
         return false;

      }

   } else {

      alert ( "Delivery Note Date is required" );
      return false;
   }

   if( $('#buyerOrderDate').val() != "" ){
      if( $('#buyerOrderNo').val() == "" ){
        alert( 'Buyer Order No. cannot be blank.' );
        return false;
      }
   }

   if ( buyerName != "Select" ){

      buyerNameValid = true;

   } else {

      alert ( "Buyer Name is required. Please select from dropdown menu" );
      return false;
   }

   if ( deliveryNoteItemCount > 0 ){

      deliveryNoteItemValid = true;

   } else {

      alert ( "Minimum 1 product item is required" );
      return false;
   }

   if ( deliveryNoteDateValid && buyerNameValid && deliveryNoteItemValid ){

    result = true;

   } else {

    result = false

   }

   return result;
}
/*
function setDeliveryNoteNumber()
{
    $.ajax({
      url: 'get_data.php',
      type: 'post',
      data: { "function" : "getDeliveryNoteNumber" },
        success: function(response) 
        { 
          $('#deliveryNoteNo').val( response );
        },
        fail: function(e)
        {
          alert("Please try after sometime");
        }
    });
}

function postDeliveryNoteData( deliveryNoteData, deliveryNoteItemData )
{
    $.ajax({
      url: 'get_data.php',
      type: 'post',
      data: { "function" : "postDeliveryNoteData", "param" : deliveryNoteData, "param2" : deliveryNoteItemData },
        success: function(response) 
        { 
            location.href = "view_delivery_note.php";
        },
        fail: function(e)
        {
            alert("Please try after sometime : " + e );
        }
    });
}
*/
</script>