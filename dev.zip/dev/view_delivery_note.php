<?php 
	require_once "includes/header.php";

	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}

	$per_page_limit = 7;//50
	$total_pages = 0;
	$page = 0;
	$offset = 0;
		
	$sql = "SELECT count(*) FROM delivery_notes";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );

	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:view_delivery_note.php");
	} 

?>

<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		require_once "includes/sides.php";
	?>
    <div class="col-sm-10 text-left"> 
      <h1>Delivery Note Management</h1>
      <ul class="pagination">
        <?php
        	if( $total_pages > 1 ){	
          		for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          			<li><a href="view_delivery_note.php?page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
        		}
          }
        ?>
      </ul>
      <div class="clear"></div>
      <a href="add_delivery_note.php" type="button" class="btn btn-success addProduct">Add Delivery Note</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
        	<tr>
	            <th>Delivery Note ID</th>
	            <th>Delivery Note No.</th>
				<th>Delivery Note Date</th>
				<th>Buyer Name</th>
				<th>Buyer Order No.</th>
				<th>Buyer Order Date</th>
				<th>Action</th>
          	</tr>
        </thead>
        <tbody>
          
	<?php        
		$sql="SELECT * FROM delivery_notes LIMIT $offset, $per_page_limit";
		$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

		while($row=mysqli_fetch_array($result))
    	{ 
	?>
 			<tr>
		 		<td><?php echo $row['del_note_id']; ?></td>
          		<td><?php echo $row['del_note_no']; ?></td>
		  		<td><?php 
		  			$date = date_create( $row['del_note_date'] );
					echo date_format( $date, "d/m/Y" );
		  		?></td>
		  		<td><?php 
				
					$custid = $row['cust_id']; 
					$sql2="SELECT cust_name FROM customers WHERE cust_id='$custid'";
					$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
					while($row2=mysqli_fetch_array($result2))
					{
						echo $row2[0];
					}
			  
			  		?>
		  		</td>
		  		<td><?php echo $row['buyer_order_no']; ?></td>
				<td><?php 
					if( isset( $row['buyer_order_date'] ) ){
		  				$date = date_create( $row['buyer_order_date'] );
						echo date_format( $date, "d/m/Y" );
		  			}
		  			?></td>
		  		<td>
		  			<a href="dn/view_specific_delivery_note.php?del_note_id=<?php echo $row['del_note_id'];?>" target="_blank">View</a><?php 
              if( $_SESSION['type'] != 100 ){
            ?>
             |
		  			<!--a href="update_delivery_note.php?edit=< ?php echo $row['del_note_id'];?>">Edit</a> | -->
		  			<a href="#" class='delete_del_note' data-link="delete_delivery_note.php?delete=<?php echo $row['del_note_id'];?>">Delete</a>
            <?php 
              }
            ?>
		  		</td>
			</tr>	
	<?php
		}
	?>  
        </tbody>
      </table>
    </div>
  </div>
</div>

 <script>

$(document).ready(function()
{
    $(".delete_del_note").click(function()
    {
		var location = $(this).attr("data-link");

        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
	
		} else{
			
			return false;
		}
    });
});

</script>

<?php
	require_once "includes/footer.php";
?>
