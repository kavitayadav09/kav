<?php 
	include_once "includes/header.php";

	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
	

    $per_page_limit = 50;
	$total_pages = 0;
	$page = 0;
	$offset = 0;
		
	$sql = "SELECT count(*) FROM customers ";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );

	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:view_customer.php");
	} 
	  	
?>
  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Customer Management</h1>
      <ul class="pagination">
        <?php
        	if( $total_pages > 1 ) {
        		for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          			<li><a href="view_customer.php?page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
        		}
          	}
        ?>
      </ul>
      <div class="clear"></div>
      <a href="add_customer.php" type="button" class="btn btn-success addUser">Add Customer</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>
           
            <!--th>Customer ID</th-->
            <th>Customer Name</th>
			<th>Customer Email</th>
			<th>Customer Mobile</th>
			<th>Customer Address</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          
<?php        
//$id=$_POST['m_id'];
//$name=$_POST['m_name'];

$sql="SELECT cust_id, cust_name, cust_email, mobile, address FROM customers LIMIT $offset, $per_page_limit";
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	   while($row=mysqli_fetch_array($result))
    {  
?>
        <tr>
		  <!--td>< ?php echo $row['cust_id']; ?></td-->
          <td><?php echo $row['cust_name']; ?></td>
		  <td><?php echo $row['cust_email']; ?></td>
		  <td><?php echo $row['mobile']; ?></td>
		  <td><?php echo $row['address']; ?></td>
		  <td><a href="update_customer.php?edit=<?php echo $row['cust_id'];?>">Edit</a><?php 
              if( $_SESSION['type'] != 100 ){
            ?>
             |
		  <a href="#" class='abc' data-link="delete_customer.php?delete=<?php echo $row['cust_id'];?>">delete</a>
            <?php 
              }
            ?></td>
		</tr>
		
<?php
	}
?>
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>

$(document).ready(function(){
    $(".abc").click(function(){
		
		var location = $(this).attr("data-link");
        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
	
			}
		else{
				return false;
		}
    });
});
</script>

<?php
	include_once "includes/footer.php";

?>