<?php

	require_once 'config/config.php';

	session_start();

	if( isset( $_SERVER ['HTTP_REFERER'] ) ){
      $referrer = $_SERVER ['HTTP_REFERER'];
      $firstIndex = strripos( $referrer, BASEPATH );
      //echo "$referrer";

      if( $firstIndex >= 0 ){
        //proceed
      } else {
        header( 'location:'.$base_url.'logout.php' );
        exit();
      }
    } else {
      header( 'location:'.$base_url.'logout.php' );
      exit();
    }
    
	if( isset($_SESSION['user_id']) ){
		//proceed
	} else {
		header( 'Location:logout.php' );
	}
	
	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
		}
	}


if(isset($_GET['delete'])){
	
	$id = $_GET['delete'];


	$sql = "DELETE FROM products WHERE product_id=$id AND sold<>1";
	//$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	if(mysqli_query($conn, $sql)){
		//if success - means the product exists in products table
	}else{
		//otherwise delete from defective_products table
		$sql = "DELETE FROM defective_products WHERE product_id=$id AND sold<>1";
		$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	}

	
}

header('location:display_product.php?maid='.$_GET['maid'].'&moid='.$_GET['moid'].'');
?>