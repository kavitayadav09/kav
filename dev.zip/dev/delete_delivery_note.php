<?php

require_once 'config/config.php';

session_start();

if( isset( $_SERVER ['HTTP_REFERER'] ) ){
  $referrer = $_SERVER ['HTTP_REFERER'];
  $firstIndex = strripos( $referrer, BASEPATH );
  //echo "$referrer";

  if( $firstIndex >= 0 ){
    //proceed
  } else {
    header( 'location:'.$base_url.'logout.php' );
    exit();
  }
} else {
  header( 'location:'.$base_url.'logout.php' );
  exit();
}

if( isset($_SESSION['user_id']) ){
	//proceed
} else {
	header( 'Location:logout.php' );
}

if( !isset( $_SESSION['type'] )){
	//show nothing
	header( 'Location:logout.php' );
} else {
	if( $_SESSION['type'] == 1 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
}

if(isset($_GET['delete'])){
	
	$id = $_GET['delete'];
	
	$sql = "SELECT count(*) FROM delivery_note_items WHERE del_note_id='$id'";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row = mysqli_fetch_array( $result );
	$count = $row[0];
	$tmp_count = 0;
	//echo ">>>>>>>>".$count."<<<<<<<<<";
	$sql = "SELECT * FROM delivery_note_items WHERE del_note_id='$id'";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	while ( $row = mysqli_fetch_array( $result ) ) {
		
		$product_id = $row['product_id'];
		$model_id = $row['model_id'];
		//echo "product_id = " . $product_id . " ::: " . $tmp_count;
		
		//unbind items marked sold against this delivery note
		$sql2 = "UPDATE products SET sold='0', sold_date=NULL WHERE product_id='$product_id' AND sold='1'";
		$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
	    if( mysqli_affected_rows($conn) == 0 ){
	    	$sql3 = "UPDATE defective_products SET sold='0', sold_date=NULL WHERE product_id='$product_id' AND sold='1'";
			$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
	    }

		if( $tmp_count == ( $count - 1 ) ){
			//echo "YAHOO";
			//remove from delivery note items 
		    $sql4 = "DELETE FROM delivery_note_items WHERE del_note_id='$id'";
		    $result4 = mysqli_query($conn, $sql4) or die("Error in Selecting " . mysqli_error($conn));

			$sql = "DELETE FROM delivery_notes WHERE del_note_id = ?";
			$stmt = $conn->prepare( $sql );
			$stmt -> bind_param( "s", $id );
			if ( $stmt->execute() === TRUE ) {
				header('location:view_delivery_note.php');

			} else {
				$result = "Error: " . $sql . "<br>" . $conn->error;
				return $result;
			}
		}
		
		$tmp_count++;
	}
}

?>