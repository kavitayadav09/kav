<?php

	require_once 'config/config.php';

	session_start();

	if( isset( $_SERVER ['HTTP_REFERER'] ) ){
      $referrer = $_SERVER ['HTTP_REFERER'];
      $firstIndex = strripos( $referrer, BASEPATH );
      //echo "$referrer";

      if( $firstIndex >= 0 ){
        //proceed
      } else {
        header( 'location:'.$base_url.'logout.php' );
        exit();
      }
    } else {
      header( 'location:'.$base_url.'logout.php' );
      exit();
    }
    
	if( isset($_SESSION['user_id']) ){
		//proceed
	} else {
		header( 'Location:logout.php' );
		exit();
	}
	
	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
		exit();
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
			exit();
		}
	}


if( isset( $_GET['maid'] ) && isset( $_GET['moid'] ) ){
	$manufacturer_id = $_GET['maid'];
	$model_id = $_GET['moid'];
	$sql = "DELETE FROM products WHERE manufacturer_id=$manufacturer_id AND model_id=$model_id";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	$sql = "DELETE FROM defective_products WHERE manufacturer_id=$manufacturer_id AND model_id=$model_id";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
}

header('location:view_product.php');
?>