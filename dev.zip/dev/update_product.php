<?php
include_once "includes/header.php";

if( isset( $_GET['maid'] ) && isset( $_GET['moid'] ) && isset($_GET['edit']) ){
	$manufacturer_id = $_GET['maid'];
	$model_id = $_GET['moid'];

	$product_id = $_GET['edit'];

	$sql="SELECT * FROM products WHERE product_id='$product_id'";

	$result = mysqli_query($conn,$sql);

   	$row = mysqli_fetch_array($result);   

} else {
	header("location:view_product.php");
	exit();
}
   
if(isset($_POST['submit'])){
	$slno=$_POST['serial_no'];
	$manufacturer_id=$_POST['m_id'];
	$model_id=$_POST['models_cb'];

	$sql=null;
	
	if( isset( $slno ) ){
		//check if the serial no exists
		if( is_numeric($slno) ){
			$product_check_sql = "SELECT * FROM products WHERE serial_no=$slno AND model_id='$model_id'";
		} else {
			$product_check_sql = "SELECT * FROM products WHERE serial_no='$slno' AND model_id='$model_id'";
		}
		
		$product_check_result = mysqli_query($conn, $product_check_sql) or die("Error in Selecting " . mysqli_error($conn));
		$product_check_row = mysqli_fetch_array( $product_check_result );

		if( isset( $product_check_row['product_id'] ) ){
			//exists
			//do not add to system

		} else {
			$sql="UPDATE products SET serial_no='$slno', manufacturer_id='$manufacturer_id', model_id='$model_id' WHERE product_id='$product_id'";
		}
		
	} else {
		$sql="UPDATE products SET manufacturer_id='$manufacturer_id', model_id='$model_id' WHERE product_id='$product_id'";
	}

	if( isset( $sql ) ){
		if( $conn->query($sql) === TRUE ) {
		    echo "New record updated successfully";
		    $conn->close();
			header("Location:display_product.php?maid=".$manufacturer_id."&moid=".$model_id);
			exit();
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}
	} else {
		echo "This Serial No. already exists.";
	}
}
?> 
 
<?php
	include_once "includes/sides.php";
?>

<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Product Information</h1>
 

	 <?php
		//$m_id=$row['m_id'];
		//$sql3 = "SELECT * FROM models WHERE id='$model_id'";
		//$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));

?>  

         <form action="" method="post" class="form-horizontal customform">
		  
		  <!--div class="form-group">
            <label class="control-label col-sm-3" for="email">Product Name:</label>
            <div class="col-sm-9">
              <input type="text" name="product_name" value="< ?php echo $row['product_name']; ?>" class="form-control" id="addname" placeholder="Enter Product Name" required>
            </div>
          </div-->
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Serial No:</label>
            <div class="col-sm-9">
            
              <input type="text" name="serial_no" value="<?php 
              	if( isset( $row['serial_no'] ) && $row['serial_no'] != "" ) { 
              		echo $row['serial_no']; 
              	}else { 
              		echo ""; 
              	} ?>" class="form-control" autocomplete="off" id="serial_no" placeholder="Enter Serial no" <?php
              	if( $row['serial_no'] != 0){ 
              		//echo "readonly";
              	}?> >
			   
            </div>
          </div>
		  
		   
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-9">
		
				<select name="m_id" id="m_id" class="form-control" required>
				<option value="">Select</option>
				<?php 
					$sql2 = "SELECT * FROM manufacturers";
					$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
					while($row2=mysqli_fetch_array($result2))
					{	
				?>
					<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
				<?php
					echo '<script>jQuery("#m_id").val("'.$row['manufacturer_id'].'");</script>';
				  ?>  		  	  
			</div>	
		</div>  
		<div class="form-group">
		<label class="control-label col-sm-3" for="pwd">Model:</label>
		<div class="col-sm-9">		
			<select name="models_cb" id="models_cb" class="form-control" required onchange="checkForSerializedModel();">
			<option value="">Select</option>
			<?php 
					$sql2 = "SELECT * FROM models WHERE manufacturer_id='$manufacturer_id'";
					$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
					while($row2=mysqli_fetch_array($result2))
					{
						$m_desc = rawurlencode( $row2['model_desc'] );
						echo ">>".$m_desc;
				?>
					<option value="<?php echo $row2[0];?>" data-serialized="<?php echo $row2['serialized'];?>" data-desc="<?php echo $m_desc;?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
				<?php
					echo '<script>jQuery("#models_cb").val("'.$row['model_id'].'");</script>';
				 ?> 

		</div>
		 
		</div>
 		  
 		  <div class="form-group">
				<label class="control-label col-sm-3" for="email">Model Description:</label>
				<div class="col-sm-8">
				  <input type="text" class="form-control" id="model_desc" placeholder="" readonly>
				</div>
			</div>
		  

		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Update</button>
            <?php 
              }
            ?>
			  <a href="display_product.php?maid=<?php echo $manufacturer_id;?>&moid=<?php echo $model_id;?>" type="button" class="btn btn-success backproduct">Back</a>
            </div>
          </div>
         
        </form> 
 
</div>
</div>
 
<?php
	include_once "includes/footer.php";

?>

<script>

function checkForSerializedModel()
{
	var serialized = $('#models_cb option:selected').attr('data-serialized');
	if( serialized == '1' ){
		$("#serial_no").attr( 'disabled', true );
	} else {
		$("#serial_no").attr( 'disabled', false );
	}
	var desc = unescape( $('#models_cb option:selected').attr('data-desc') );
	if( desc == null || desc == 'null' || desc == undefined || desc == 'undefined' ){
		desc = "";
	}
	$("#model_desc").val( desc );
}

function updateModel(a) 
{
    $("#model_desc").val( "" );
	
	var data = {
        mid: a
    };
	
	$('#models_cb').empty();
	$('#models_cb').append( '<option value="0">Select</option>' );
	
    try{
      $.ajax({
          type: "POST",
          url: "get_model_by_id.php",
          data: data,
          success: function(data){
			//alert(data);
			var dataObj = JSON.parse(data);
			//alert(dataObj[0].id);
			
			$.each( dataObj, function(key,value) {
			  var desc = value.desc;
				  $('#models_cb').append( '<option value="'+value.id+'" data-serialized="'+value.serialized+'" data-desc="'+escape(desc)+'"">'+value.name+'</option>' );
			}); 			 
          },
          fail: function(e){
            alert("Please try after sometime");
          }
      });
    } catch(e){
      
    }
  }

$(document).ready(function(){
	var c = $("#m_id").val();

	checkForSerializedModel();

    $("#m_id").change(function(){
		var b = $(this).val()
        updateModel(b);
    });
	
	 $("#addno").keyup(function(){
		 var quentity = $("#addquantity").val();
		
		 
		 if(quentity!=1){
			 $(".serialno").show()
			
			 $(this).val('')
			 //console.log('true');
		 }
		 else{
			 $(".serialno").hide()
		 }
			 
	 })
	 
	 
	 
	  $("#addquantity").on('change keyup',function(){
		 var quentity = $(this).val();
		  
		 if(quentity!=1){
			 $(this).val(1);
			 //$(".serialno").show()
			
			 //console.log('true');
		 }
		 else{
			 $(".serialno").hide()
		 }
			 
	 })
});
</script>

<!--?php
			//echo '<script>jQuery("#master_id").val("'.$row['master_id'].'");</script>';
			echo '<script>
			$(document).ready(function(){
				//alert(jQuery("#master_id").length)
				setTimeout(function(){ 
			jQuery("#master_id").val('.$row['master_id'].');
			 }, 1000);
			})
			</script>';
			//echo $row['master_id'];
		  ?-->