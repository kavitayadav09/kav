<?php 
	include_once "includes/header.php";
	
	if( isset( $_GET['maid'] ) && isset( $_GET['moid'] ) ){
		$manufacturer_id = $_GET['maid'];
		$model_id = $_GET['moid'];	
	} else {
		header("location:view_product.php");
		exit();
	}
	
	$per_page_limit = 50;
	$total_pages = 0;
	$page = 0;
	$offset = 0;
	$sql = "SELECT count(*) FROM (SELECT NP.product_id, NP.manufacturer_id, NP.model_id, NP.serial_no  
FROM (SELECT P.product_id, P.manufacturer_id, P.model_id, P.serial_no FROM products P WHERE P.sold='0' AND P.model_id='$model_id' UNION SELECT DP.product_id, DP.manufacturer_id, DP.model_id, DP.serial_no FROM defective_products DP WHERE DP.sold='0' AND DP.active='2' AND DP.model_id='$model_id') AS NP) AS NP2";

	//$sql = "SELECT count(*) FROM products where model_id='$model_id' AND sold='0'";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );
	
	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:display_product.php?maid=".$manufacturer_id."&moid=".$model_id."");
	} 
?>

  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Product Management</h1>
       <ul class="pagination">
        <?php
        	if( $total_pages > 1 ) {
          		for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          			<li><a href="display_product.php?maid=<?php echo $manufacturer_id;?>&moid=<?php echo $model_id;?>&page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
        		}
          	}
        ?>
      </ul>
      <div class="clear"></div>
      <a href="view_product.php" type="button" class="btn btn-success addProduct">Back</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>
           	<th>Manufacturer</th>
            <th>Model Name</th>
			<th>Serial No</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          
		<?php        

		//$sql1="SELECT * FROM products WHERE manufacturer_id='$manufacturer_id' AND model_id='$model_id' AND sold='0' LIMIT $offset, $per_page_limit";
		$sql1="SELECT NP.product_id, NP.manufacturer_id, NP.model_id, NP.serial_no  
FROM (SELECT P.product_id, P.manufacturer_id, P.model_id, P.serial_no FROM products P WHERE P.sold='0' AND P.model_id='$model_id' UNION SELECT DP.product_id, DP.manufacturer_id, DP.model_id, DP.serial_no FROM defective_products DP WHERE DP.sold='0' AND DP.active='2' AND DP.model_id='$model_id') AS NP  LIMIT $offset, $per_page_limit";

		$result = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));
		//$count = 0;
		while($row=mysqli_fetch_array($result))
	    { 
		/*for($i=0; $i<$row['quantity']; $i++){
			$count++;
			if($count>$row['quantity']){
				$count=1;
			}*/
		?>
		<tr>

			<td><?php 
				$sql2="SELECT m_name FROM manufacturers WHERE m_id='$manufacturer_id'";
				$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
				while($row2=mysqli_fetch_array($result2))
				{
					echo $row2[0];
				}
		  	?></td>

		  <td><?php 
			//$master_id = $row['master_id']; 
			$sql3="SELECT model_name FROM models WHERE id='$model_id'";
			$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
			while($row3=mysqli_fetch_array($result3)){
				echo $row3[0];
			}
		  ?></td>

		  <td><?php 
		  if( $row['serial_no'] == '0') { 
              		echo ""; 
              	}else { 
              		echo $row['serial_no']; 
              	}
             ?></td>
	
		  
		  <td><a href="update_product.php?edit=<?php echo $row['product_id'];?>&maid=<?php echo $manufacturer_id;?>&moid=<?php echo $model_id;?>">Edit</a><?php 
              if( $_SESSION['type'] != 100 ){
            ?>
             |
		  <a href="#" class='abc' data-link="delete_product.php?delete=<?php echo $row['product_id'];?>&maid=<?php echo $manufacturer_id;?>&moid=<?php echo $model_id;?>">Delete</a>
            <?php 
              }
            ?></td>
		</tr>
		
<?php
		//}
	}
?>  
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>

$(document).ready(function(){
    $(".abc").click(function(){
		
		var location = $(this).attr("data-link");
        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
	
			}
		else{
				return false;
		}
    });
});
</script>

<?php
	include_once "includes/footer.php";

?>