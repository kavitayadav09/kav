
<?php
require_once 'config/config.php';
session_start();

$msg = "";

if (isset($_POST['submit'])){
  $name=$_POST['user_email'];
  $password=$_POST['password'];

  $sql="SELECT user_id, user_name, password, type FROM user WHERE user_email='$name' AND password='$password'";
  $result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

  if($row = mysqli_fetch_array($result)){
  	$_SESSION['user_id']=$row['user_id'];
  	$_SESSION['user_name']=$row['user_name'];
  	$_SESSION['type']=$row['type'];
  	header("Location:dashboard.php");
  	exit();
  } else {
    $msg = "Wrong Credentials!";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>CMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"
		integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
		crossorigin="anonymous"></script>
 
</head>
<body>
<nav class="navbar navbar-inverse innerNav">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#"><img class="img-responsive logo" src="img/webdesk_logo.jpg" alt="" width="110px"></a>
    </div>
  </div>
</nav>

<body class="Login">
  <section class="container">
    <form action="" method="post" class="loginForm">
      <!--img class="img-responsive logo" src="img/logo1.jpg" alt=""-->
    <h5><?php echo $msg;?></h5>
	  <h1 class="formHedings">Login</h1>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="text" name="user_email" class="form-control" id="name" required>
      </div>
      <div class="form-group">
        <label for="pwd">Password:</label>
        <input type="password" name="password" class="form-control" id="pwd" required>
      </div>
      <div class="checkbox">
        <label><input type="checkbox"> Remember me</label>
      </div>
      <input type="submit" name="submit" class="btn btn-default" value="Login">
	  <center><a href="forgot_password.php"  class="back">forgot Password</a></center>
    </form>
  </section>
  <footer class="container-fluid text-center">
  <p>Webdesk Technologies © 2017-18</p>
</footer>
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>