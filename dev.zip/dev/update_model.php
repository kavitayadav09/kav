<?php
include_once "includes/header.php";

if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
	//admin
} else {
	header( 'Location:logout.php' );
}

if(isset($_GET['edit'])){
	$id = $_GET['edit'];
	$sql="SELECT * FROM models WHERE id='$id'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);    
}

if(isset($_POST['submit'])){
	$name=$_POST['model_name'];
	$desc = addslashes($_POST['model_desc']);
	$m_id=$_POST['m_id'];

	$sql="UPDATE models SET model_name='$name', model_desc='$desc', manufacturer_id='$m_id' WHERE id='$id'";

	if ($conn->query($sql) === TRUE) {
	    echo "Updated Model Information successfully!";
	    $conn->close();
		header("Location:view_model.php");

	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}

?> 

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
    <h1>Update Model Information</h1>
	
         <form action="" method="post" class="form-horizontal customform">
		  
		  <!--div class="form-group">
            <label class="control-label col-sm-3" for="email">Model Id:</label>
            <div class="col-sm-8">
              <input type="text" name="model_id" value="< ?php echo $row['model_id']; ?>" class="form-control" id="addid" placeholder="Enter Manufacturer Name" readonly>
            </div>
          </div-->
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
			
				<select name="m_id" id="m_id" class="form-control" required>
				<option value="">Select</option>
				<?php
					$sql2 = "SELECT * FROM manufacturers";
					$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

					while($row2=mysqli_fetch_array($result2)){	
				?>
					<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
			</div>
			</div>

		  <div class="form-group">
            <label class="control-label col-sm-3"></label>
            <div class="col-sm-8">
              <input type="checkbox" name="model_serialize" id="model_serialize" <?php 
              	if( isset( $row['serialized'] ) ){
              		echo "value='".$row['serialized']."'";
              		if( $row['serialized'] == 0 ){
              			echo "checked";
              		}
              	}
               ?>> Model has Serial No.
            </div>
          </div>

		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Name:</label>
            <div class="col-sm-8">
              <input type="text" name="model_name" value="<?php echo $row['model_name']; ?>" class="form-control" id="addname" placeholder="Enter Model Name">
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Description:</label>
            <div class="col-sm-8">
              <textarea class="form-control" rows="5" name="model_desc" id="model_desc" placeholder="Enter Model Description" ><?php 
              	if( isset( $row['model_desc'] ) ){
              		echo $row['model_desc'];
              	} else {
              		echo "";
              	} ?></textarea>
            </div>
          </div>
		  
		  
		  <?php
			echo '<script>jQuery("#m_id").val("'.$row['manufacturer_id'].'");</script>';
		  ?>
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Update</button>
            <?php 
              }
            ?>
			  <a href="view_model.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
</div>
<?php
	include_once "includes/footer.php";

?>