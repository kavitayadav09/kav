<?php

	include_once "includes/header.php";
	
	if( $_SESSION['type'] == 1 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
   
   $msg = "";

	if(isset($_POST['submit'])) {
		$model_name = $_POST['model_name'];
		//$serialize = $_POST['model_serialize'];
		if( isset( $_POST['model_serialize'] ) && $_POST['model_serialize'] == 0 ){
			//checked
			$serialize = 0;	
		} else {
			$serialize = 1;	
		}
		
		//echo ">>>".$serialize;
		//exit();

		//check for duplicacy
		$sql = "SELECT * FROM models WHERE model_name='$model_name'";
		$result = mysqli_query( $conn, $sql ) or die("Error in Selecting " . mysqli_error($conn));
	    $row = mysqli_fetch_array( $result );
	    
	    if( !isset( $row['model_name'] ) ){
			if( isset( $_POST['model_name'] ) ){
				$name = $_POST['model_name'];
			} else {
				$name = NULL;
			}

			$desc = addslashes($_POST['model_desc']);
			$mid = $_POST['m_id'];

			$sql="INSERT INTO models ( model_name, model_desc, manufacturer_id, serialized ) VALUES( '$name', '$desc', '$mid', '$serialize' )";

			if ($conn->query($sql) === TRUE) {
			    $msg = "New Model added successfully!";
			} else {
			    $msg = "Error: " . $sql . "<br>" . $conn->error;
			}

			header("Location:view_model.php");
			$conn->close();

	    } else {
	    	$msg = "A Model With Same ID already exists.";
	    }
	}

	echo "$msg";
?> 

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
    <div class="col-sm-6 text-left marginAuto AddUser"> 
    <h1>Add Model Information</h1>
	  
	<?php

		$sql2 = "SELECT * FROM manufacturers";
		$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
	?>
         <form action="" method="post" class="form-horizontal customform">
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
			
			<select name="m_id" class="form-control" required>
			<option value="">Select</option>
			<?php 
				while($row2=mysqli_fetch_array($result2))
				{	
			?>
				<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			<?php
				}
			?>


			</select>
			</div> 
			</div>

			<div class="form-group">
            <label class="control-label col-sm-3"></label>
            <div class="col-sm-8">
              <input type="checkbox" name="model_serialize" id="model_serialize" value="0" checked> Model has Serial No.
            </div>
          </div>

		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Model Name:</label>
            <div class="col-sm-8">
              <input type="text" name="model_name" class="form-control" id="model_name" placeholder="Enter Model Name" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Description:</label>
            <div class="col-sm-8">
              <textarea class="form-control" rows="5" name="model_desc" id="model_desc" placeholder="Enter Model Description" ></textarea>
            </div>
          </div>
		  
		   <!--div class="form-group"-->
            <!--label class="control-label col-sm-3" for="pwd">Model Price:</label-->
            <!--div class="col-sm-8"-->
              <!--input type="hidden" name="model_price" class="form-control" id="addprice" placeholder="Enter Price" required-->
            <!--/div-->
          <!--/div-->
		  
		  
					  <div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
						  <button type="submit" name="submit" class="btn btn-success" >Submit</button>
						  <a href="view_model.php" type="button" class="btn btn-success back">Back</a>
						</div>
					  </div>
					 
					</form> 
    </div>
 
</div>
<?php
	include_once "includes/footer.php";

?>

<script type="text/javascript">
	$(document).ready(function(){
	    $("#model_name").focus();
	});
</script>