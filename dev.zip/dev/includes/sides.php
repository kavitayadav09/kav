<div class="col-sm-2 sidenav sideBar">
      <ul>
	  <?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
					//admin
		?>
        <li><a href="manufacturers.php">Manufacturers</a></li>
			<?php
				}
			}
		?>
		<?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
					//admin
		?>
        <li><a href="view_model.php">Models</a></li>
			<?php
				}
			}
		?>
        
        <li><a href="view_product.php">Products</a></li>

        <li><a href="view_defective_items.php">Defective Items</a></li>
		
		<?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
					//admin
		?>
					<li><a href="view_user.php">Users</a></li>
		<?php
				}
			}
		?>
        <?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
					//admin
		?>
		<li><a href="view_customer.php">Customers</a></li>
		<?php
				}
			}
		?>

		<?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
					//admin
		?>
		<li><a href="view_delivery_note.php">Delivery Note</a></li>
		<?php
				}
			}
		?>


      </ul>
    </div>