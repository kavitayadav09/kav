<?php
	require_once 'config/config.php';
  
	session_start();

	if( isset($_SESSION['user_id']) ){
		//proceed
	} else {
		header( 'Location:logout.php' );
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Webdesk Technology - Inventory Management System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  
  <script src="script/jquery.js"></script>
  <script src="script/bootstrap.min.js"></script>
  <script src="script/custom.js"></script>
  <!--script src="https://code.jquery.com/jquery-3.2.1.min.js"	integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script-->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse innerNav">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="dashboard.php"><img class="img-responsive logo" src="img/webdesk_logo.jpg" alt="" width="110px"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <!--ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Contact</a></li>
      </ul-->
      <ul class="nav navbar-nav navbar-right settings">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Welcome <?php echo $_SESSION['user_name'];?></a></li>
        <li><a href="change_password.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>