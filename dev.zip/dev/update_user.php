<?php
include_once "includes/header.php";

if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
  //admin
} else {
  header( 'Location:logout.php' );
}


if(isset($_GET['edit']))
{
	
$uid = $_GET['edit'];

$sql="SELECT * FROM user WHERE user_id='$uid'";

$result = mysqli_query($conn,$sql);


	   $row = mysqli_fetch_array($result); 
}
	

if(isset($_POST['submit']))
{
//$uid=$_POST['user_id'];
$name=$_POST['user_name'];
$email=$_POST['user_email'];
$password=$_POST['password'];
$mobile=$_POST['mobile'];

$sql="UPDATE user SET user_name='$name', user_email='$email', password='$password', mobile='$mobile' WHERE user_id='$uid'";

if ($conn->query($sql) === TRUE) {
    echo "New record updated successfully";
	header("Location:view_user.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
	
}


?> 

<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
<div class="container-fluid text-center user">    
  <div class="row content">
    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update User Information</h1>
         <form action="" method="post" class="form-horizontal">
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">User Name:</label>
            <div class="col-sm-8">
              <input type="text" name="user_name" value="<?php echo $row['user_name']; ?>" class="form-control" id="userName" placeholder="Enter User Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">User Email:</label>
            <div class="col-sm-8">
              <input type="text" name="user_email" value="<?php echo $row['user_email']; ?>" class="form-control" id="userEmail" placeholder="Enter User Email" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="email">Password:</label>
            <div class="col-sm-8">
              <input type="password" name="password" value="<?php echo $row['password']; ?>" class="form-control" id="userPassword" placeholder="Enter User Password" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Mobile No:</label>
            <div class="col-sm-8">
              <input onkeyup="numberOnly(this)" name="mobile" value="<?php echo $row['mobile']; ?>" class="form-control" id="userMobile" placeholder="Enter User Mobile No" required>
            </div>
          </div>
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-8">
              <?php 
              if( $_SESSION['type'] != 100 ){
            ?>
            <button type="submit" name="submit" class="btn btn-success" >Update</button>
            <?php 
              }
            ?>
			  <a href="view_user.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
  </div>
</div>

<?php
	include_once "includes/footer.php";

?>
<script>
function numberOnly(input) {
	var regex = /[^0-9]/g;
	input.value = input.value.replace(regex, "");
}
</script>