<?php
require_once 'config/config.php';

if ( isset($_POST['function']) ) {

	if ( $_POST['function'] == "getDeliveryNoteNumber" ) {
		 echo getDeliveryNoteNumber($conn);
	}
}

if ( isset($_POST['function']) AND isset($_POST['param']) AND isset($_POST['param2'] ) ) {

	if ( $_POST['function'] == "postDeliveryNoteData") {
		 echo postDeliveryNoteData($conn, $_POST['param'], $_POST['param2'] );
	}
}

function getDeliveryNoteNumber($conn)
{
    $dnn = "";
    $sql = "SELECT * FROM delivery_notes";
    $result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	$rows = mysqli_num_rows($result);

	if ( $rows < 1 ){

		$dnn = "WD/CH-25/17-18";

	} else {

		$sql = "SELECT * FROM delivery_notes WHERE del_note_id = (SELECT MAX(del_note_id) FROM delivery_notes)";
		$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

		$rows = mysqli_num_rows($result);

		if ( $rows > 0 ) {

   			$rowData = mysqli_fetch_row( $result );
   			$extractDNN = $rowData[2];
   			$extractDNN = explode( "/", $extractDNN );
   			$extractDNN = $extractDNN[1];
   			$extractDNN = substr( $extractDNN, 3 );
   			$extractDNN = $extractDNN + 1;
			$extractDNN = "WD/CH-" . $extractDNN . "/17-18";
   			$dnn = $extractDNN;
		}
	}

    return $dnn;
}

// delivery note related data inserted

function postDeliveryNoteData( $conn, $deliveryNoteData, $deliveryNoteItemData )
{
	//{"deliveryNoteNo":"WD/CH-00025/17-18","deliveryNoteDate":"09/09/2017","buyerId":"1","buyerOrderNo":"","buyerOrderDate":"","despatchDestination":"","remarks":""}
	$result = "";

	$deliveryNoteData = json_decode( $deliveryNoteData );
	$deliveryNoteNo = $deliveryNoteData -> deliveryNoteNo;
	$deliveryNoteDate = $deliveryNoteData -> deliveryNoteDate;
	$buyerId = $deliveryNoteData -> buyerId;
	$buyerOrderNo = $deliveryNoteData -> buyerOrderNo;
	$buyerOrderDate = $deliveryNoteData -> buyerOrderDate;
	$despatchDestination = $deliveryNoteData -> despatchDestination;
	$remarks = $deliveryNoteData -> remarks;

	if ( $buyerOrderDate === "" ){

		$sql = "INSERT INTO delivery_notes ( cust_id, del_note_no, del_note_date, des_destination, rem ) VALUES ( ?, ?, ?, ?, ? )";

		$stmt = $conn->prepare( $sql );

		$stmt->bind_param( "sssss", $buyerId_param, $deliveryNoteNo_param, $deliveryNoteDate_param, $despatchDestination_param, $remarks_param );

		$buyerId_param = $buyerId;
		$deliveryNoteNo_param =  $deliveryNoteNo;
		$deliveryNoteDate_param = $deliveryNoteDate;
		$despatchDestination_param = $despatchDestination;
		$remarks_param = $remarks;

	} else {

		$sql = "INSERT INTO delivery_notes ( cust_id, del_note_no, del_note_date, buyer_order_no, buyer_order_date, des_destination, rem ) VALUES ( ?, ?, ?, ?, ?, ?, ? )";

		$stmt = $conn->prepare( $sql );

		$stmt->bind_param( "sssssss", $buyerId_param, $deliveryNoteNo_param, $deliveryNoteDate_param, $buyerOrderNo_param, $buyerOrderDate_param, $despatchDestination_param, $remarks_param );

		$buyerId_param = $buyerId;
		$deliveryNoteNo_param =  $deliveryNoteNo;
		$deliveryNoteDate_param = $deliveryNoteDate;
		$buyerOrderNo_param = $buyerOrderNo;
		$buyerOrderDate_param = $buyerOrderDate;
		$despatchDestination_param = $despatchDestination;
		$remarks_param = $remarks;
	}

	if ( $stmt->execute() === TRUE ) {
		
		$last_inserted_id = $conn->insert_id;

		$result = postDeliveryNoteDataItems( $conn, $last_inserted_id, $deliveryNoteItemData );

	} else {

	    $result = "Error: " . $sql . "<br>" . $conn->error;
	}

	echo $result;
}

// items inserted related to delivery notes
function postDeliveryNoteDataItems( $conn, $last_inserted_id, $deliveryNoteItemData )
{
	//[{"productId":"1=DS-7604NI-E1/4P  - CCTV Camera - 15","quantity":"2"},{"productId":"2=DS-D5019QE - Monitor - 3","quantity":"4"}]


	$result = "success";

	$deliveryNoteItemData = json_decode( $deliveryNoteItemData );

	foreach ( $deliveryNoteItemData as $item ) 
	{
    	$deliveryNoteId_param = $last_inserted_id;
		$serialNo_param = $item -> serialNo;

		if( isset( $serialNo_param ) ){
			
			//has serial number
			if( is_numeric($serialNo_param) ){
				$sql2 = "SELECT * FROM products WHERE serial_no=$serialNo_param AND sold='0'";
			} else {
				$sql2 = "SELECT * FROM products WHERE serial_no='$serialNo_param' AND sold='0'";
			}

			//echo ">>>>".$sql2;
            $result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
            $row2 = mysqli_fetch_array( $result2 );

        	$product_id = $row2['product_id'];
        	$model_id = $row2['model_id'];
        	if( $product_id == 0 ){
        		//New Product/Sold Product - cannot enter in delivery note
        		//echo "The product with Serial No. $serialNo_param is not available.";
				//exit();

				//check for the product in defective_products table
				if( is_numeric($serialNo_param) ){
					$sql2 = "SELECT * FROM defective_products WHERE serial_no=$serialNo_param AND sold='0'";
				} else {
					$sql2 = "SELECT * FROM defective_products WHERE serial_no='$serialNo_param' AND sold='0'";
				}

				//echo ">>>>".$sql2;
	            $result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
	            $row2 = mysqli_fetch_array( $result2 );

	        	$product_id = $row2['product_id'];
	        	$model_id = $row2['model_id'];

	        	if( $product_id == 0 ){
	        		//New Product/Sold Product - cannot enter in delivery note
	        		echo "The product with Serial No. $serialNo_param is not available.";
					exit();

				} else {

					$delivery_item_add_sql = "INSERT INTO delivery_note_items ( del_note_id, product_id, model_id ) VALUES( '$last_inserted_id', '$product_id', '$model_id')";
					if ($conn->query($delivery_item_add_sql) === TRUE) {
						//$result = "Successfully inserted";
						$dt = date('Y-m-d h:m:s');
						$update_product_sql = "UPDATE defective_products SET sold='1', sold_date='$dt' WHERE product_id='$product_id'";
						if(mysqli_query($conn, $update_product_sql)){

						}else{

						}

					} else {
						echo "Error: " . $sql . "<br>" . $conn->error;
					}
				}
        		
        	} else {
        		$delivery_item_add_sql = "INSERT INTO delivery_note_items ( del_note_id, product_id, model_id ) VALUES( '$last_inserted_id', '$product_id', '$model_id')";
				if ($conn->query($delivery_item_add_sql) === TRUE) {
					//$result = "Successfully inserted";
					$dt = date('Y-m-d h:m:s');
					$update_product_sql = "UPDATE products SET sold='1', sold_date='$dt' WHERE product_id='$product_id'";
					if(mysqli_query($conn, $update_product_sql)){

					}else{

					}

				} else {
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
        	}
        	
		} else {
			$qty 		= $item -> quantity;
			$modelId 	= $item -> modelId;

			//Get Product ID
			$no_serial_item_sql = "SELECT product_id FROM products WHERE model_id='$modelId' AND sold='0' LIMIT $qty";
            $no_serial_item_result = mysqli_query( $conn, $no_serial_item_sql ) or die("Error in Selecting " . mysqli_error($conn));

            while( $no_serial_item_row = mysqli_fetch_array( $no_serial_item_result ) ){
            	$p_id = $no_serial_item_row['product_id'];

            	$delivery_no_serial_item_add_sql = "INSERT INTO delivery_note_items ( del_note_id, product_id, model_id ) VALUES( '$last_inserted_id', '$p_id', '$modelId')";

				if ( mysqli_query( $conn, $delivery_no_serial_item_add_sql ) ) {
					//$result = "Successfully inserted";

					$dt = date('Y-m-d h:m:s');
					$update_no_serial_product_sql = "UPDATE products SET sold='1', sold_date='$dt' WHERE product_id='$p_id'";
					
					if( mysqli_query( $conn, $update_no_serial_product_sql ) ){
						
					}else{
						//echo "Error: " . $sql . "<br>" . $conn->error;
					}
				} else {

				}
            }
		}
	}

	return $result;
}

?>