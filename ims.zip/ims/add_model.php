<?php

	include_once "header.php";
	

	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
		}
	}
		

   
if(isset($_POST['submit']))
{
$id=$_POST['model_id'];
$name=$_POST['model_name'];
$price=$_POST['model_price'];
$mid=$_POST['m_id'];

$sql="INSERT INTO product_masters (model_id, model_name, model_price, m_id) VALUES('$id', '$name', '$price', '$mid')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:view_model.php?id= $mid");
$conn->close();
	
}


?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add Model Information</h1>
	  
	  <?php

$sql2 = "SELECT * FROM manufacturers";
$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

?>
         <form action="" method="post" class="form-horizontal customform">
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Model Id:</label>
            <div class="col-sm-8">
              <input type="text" name="model_id" class="form-control" id="addid" placeholder="Enter Model Id" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Name:</label>
            <div class="col-sm-8">
              <input type="text" name="model_name" class="form-control" id="addname" placeholder="Enter Name" required>
            </div>
          </div>
		  
		   <!--div class="form-group"-->
            <!--label class="control-label col-sm-3" for="pwd">Model Price:</label-->
            <!--div class="col-sm-8"-->
              <input type="hidden" name="model_price" class="form-control" id="addprice" placeholder="Enter Price" required>
            <!--/div-->
          <!--/div-->
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
			
			<select name="m_id" class="form-control" required>
			<option value="">Select</option>
			<?php 
				while($row2=mysqli_fetch_array($result2))
				{	
			?>
				<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			<?php
				}
			?>


			</select>
			</div> 
			</div>
					  <div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
						  <button type="submit" name="submit" class="btn btn-success" >Submit</button>
						  <a href="view_model.php" type="button" class="btn btn-success back">Back</a>
						</div>
					  </div>
					 
					</form> 
    </div>
 
</div>
<?php
	include_once "footer.php";

?>