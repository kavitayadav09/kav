<?php

	require_once 'config/config.php';
	session_start();
	if( isset($_SESSION['user_id']) ){
		//proceed
	} else {
		header( 'Location:logout.php' );
	}
	
	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
		}
	}


if(isset($_GET['delete']))
{
	
$id = $_GET['delete'];
//echo $id;

if($id==$_GET['delete']){
	echo "<script>alert('Do you want to delete')</script>";


$sql = "DELETE FROM customers WHERE cust_id=$id";
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
}
}
header('location:view_customer.php');
?>