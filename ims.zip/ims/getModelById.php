<?php
require_once 'config/config.php';

$m_id=$_POST['mid'];
$sql3 = "SELECT * FROM product_masters WHERE m_id='$m_id'";
$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));

$arr=array();

while($row3=mysqli_fetch_array($result3))
{
	$model=new stdClass();
	$model->id=$row3['master_id'];
	$model->name=$row3['model_name'];
	array_push( $arr, $model );
}

$myJSON = json_encode($arr);

echo $myJSON;

?>