<?php 
	include_once "header.php";
	
	$per_page_limit = 1;
	$total_pages = 0;
	$page = 0;
	$offset = 0;
		
	$sql = "SELECT count(*) FROM products";
	$retval = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row=mysqli_fetch_array($retval);
	
	$rec_count = $row[0];
	//echo $rec_count;
	$total_pages = ceil( $rec_count/$per_page_limit );

	if( isset($_GET{'page'} ) ) {
		$page = $_GET{'page'};
		$offset = $per_page_limit * $page ;
	}

	$left_rec = $rec_count - ($page * $per_page_limit);//8 - (0*4)//used for showing paging
	//echo "total pages: " . $total_pages;
	//echo "Page: " . $page;
	//echo "rec_count: " . $rec_count;
	
	if( $page > ( $total_pages - 1 ) && $rec_count > 0 ){
		header("location:view_product.php");
	} 
	  
	
?>

  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>Product Management</h1>
       <ul class="pagination">
        <?php
          for( $i=0; $i<$total_pages; $i++ ) {
        ?>
          <li><a href="view_product.php?page=<?php echo $i;?>"><?php echo ($i+1);?></a></li>
        <?php
          }
        ?>
      </ul>
      <div class="clear"></div>
      <a href="add_product.php" type="button" class="btn btn-success addProduct">Add Product</a>
        
      <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>
           
            <th>Product ID</th>
            <th>Product Name</th>
			<th>Quantity</th>
			<th>Serial No</th>
			<th>Manufacturer</th>
			<th>Model</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          
<?php        
//$id=$_POST['m_id'];
//if(isset($_GET['id']))

	
//$id = $_GET['id'];
//echo "<p>".$id."</p>";
//$name=$_POST['m_name'];
$sql1="SELECT * FROM products LIMIT $offset, $per_page_limit";
$result = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));

	while($row=mysqli_fetch_array($result))
    { 
?>
 <tr>
		  <td><?php echo $row['product_id']; ?></td>
          <td><?php echo $row['product_name']; ?></td>
		  <td><?php echo $row['quantity']; ?></td>
		  <td><?php echo $row['serial_no']; ?></td>
		
		  <td><?php 
			$mid = $row['m_id']; 
			$sql2="SELECT m_name FROM manufacturers WHERE m_id='$mid'";
			$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
			while($row2=mysqli_fetch_array($result2))
			{
				echo $row2[0];
			}
		  
		  ?></td>
		  
		  <td><?php 
			$master_id = $row['master_id']; 
			$sql3="SELECT model_name FROM product_masters WHERE master_id='$master_id'";
			$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
			while($row3=mysqli_fetch_array($result3))
			{
				echo $row3[0];
			}
		  
		  ?></td>
		  <td><a href="update_product.php?edit=<?php echo $row['product_id'];?>">Edit</a> |
		  <a href="#" class='abc' data-link="delete_product.php?delete=<?php echo $row['product_id'];?>">delete</a></td>
		</tr>
		
<?php
	}
?>  
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>

$(document).ready(function(){
    $(".abc").click(function(){
		
		var location = $(this).attr("data-link");
        if(confirm('Do you you want to delete...!!!!')){
			//alert($(this).attr("data-link"));
			window.location.replace(location);
	
			}
		else{
				return false;
		}
    });
});
</script>

<?php
	include_once "footer.php";

?>