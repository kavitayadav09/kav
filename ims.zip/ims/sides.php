<div class="col-sm-2 sidenav sideBar">
      <ul>
	  <?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 ){
					//admin
		?>
        <li><a href="manufacturers.php">Manufacturers</a></li>
			<?php
				}
			}
		?>
		<?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 ){
					//admin
		?>
        <li><a href="view_model.php">Models</a></li>
			<?php
				}
			}
		?>
        <li><a href="view_product.php">Products</a></li>
	
		<?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 ){
					//admin
		?>
					<li><a href="view_user.php">users</a></li>
		<?php
				}
			}
		?>
        <?php
			if( !isset( $_SESSION['type'] )){
				//show nothing
			} else {
				if( $_SESSION['type'] == 1 ){
					//admin
		?>
		<li><a href="view_customer.php">Customers</a></li>
		<?php
				}
			}
		?>
      </ul>
    </div>