<?php
include_once "header.php";
   
if(isset($_POST['submit']))
{
$name=$_POST['product_name'];
$no=$_POST['serial_no'];
$quantity=$_POST['quantity'];
$m_id=$_POST['m_id'];
$master_id=$_POST['master_id'];

$sql="INSERT INTO products (product_name, serial_no, quantity, m_id, master_id) VALUES('$name', '$no', '$quantity', '$m_id', '$master_id')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:view_product.php");
$conn->close();

}


?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add Product Information</h1>
	  
	  <?php
$sql2 = "SELECT * FROM manufacturers";
$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

?>
         <form action="" method="post" class="form-horizontal customform">
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Product Name:</label>
            <div class="col-sm-8">
              <input type="text" name="product_name" class="form-control" id="addname" placeholder="Enter Product Name" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Serial No:</label>
            <div class="col-sm-8">
              <input type="text" name="serial_no" class="form-control" autocomplete="off" id="addno" placeholder="Enter Serial No" required />
			  <p class="serialno">Select only one item</p>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Quantity:</label>
            <div class="col-sm-8">
              <input type="number" min="1" max="100" name="quantity" class="form-control" id="addQuantuty" placeholder="Enter Quantity" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
			
			<select name="m_id" class="m_id form-control" required>
			<option value="">Select</option>
			<?php 
				while($row2=mysqli_fetch_array($result2))
				{	
			?>
				<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
			<?php
				}
			?>
			</select>
		</div>
	</div>


		<div class="form-group">
			<label class="control-label col-sm-3" for="pwd">Model Name:</label>
			<div class="col-sm-8">
				<select name="master_id" id="master_id" class="form-control" required>
				<option value="">Select</option>
				</select>
			</div>
		</div>
		  
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Add</button>
			  <a href="view_product.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
</div>
</div>
<?php
	include_once "footer.php";

?>
<script>

function updateModel(a) {
    //alert(a);
	
	var data = {
        mid: a
    };
	
	$('#master_id').empty();
	$('#master_id').append( '<option value="0">Select</option>' );
	
    try{
      $.ajax({
          type: "POST",
          url: "getModelById.php",
          data: data,
          success: function(data){
			//alert(data);
			var dataObj = JSON.parse(data);
			//alert(dataObj[0].id);
			
			$.each( dataObj, function(key,value) {
			  //alert(value.id + " : "  + value.name);
	  
			  $('#master_id').append( '<option value="'+value.id+'">'+value.name+'</option>' );
			}); 			 
          },
          fail: function(e){
            alert("Please try after sometime");
          }
      });
    } catch(e){
      
    }
  }

$(document).ready(function(){
    $(".m_id").change(function(){
		var b = $(this).val()
        updateModel(b);
    });
	
	 $("#addno").keyup(function(){
		 var quentity = $("#addQuantuty").val();
		 
		 if(quentity!=1){
			 $(".serialno").show()
			
			 $(this).val('')
			 //console.log('true');
		 }
		 else{
			 $(".serialno").hide()
		 }
			 
	 })
	 
	 
	 
	  $("#addQuantuty").change(function(){
		 var quentity = $(this).val();
		 
		 if(quentity!=1){
			 //$(".serialno").show()
			
			 //console.log('true');
		 }
		 else{
			 $(".serialno").hide()
		 }
			 
	 })
	 
	 
});
</script>