
<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>