<?php
include_once "header.php";



if(isset($_GET['edit']))
{
	
$mid = $_GET['edit'];

$sql="SELECT m_name FROM manufacturers WHERE m_id='$mid'";

$result = mysqli_query($conn,$sql);


	   $row = mysqli_fetch_array($result); 
}
	

if(isset($_POST['submit']))
{
$name=$_POST['m_name'];

$sql="UPDATE manufacturers SET m_name='$name' WHERE m_id='$mid'";

if ($conn->query($sql) === TRUE) {
    echo "New record updated successfully";
	header("Location:manufacturers.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
	
}


?> 

<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "sides.php";

	?>

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Manufacturers Information</h1>
         <form action="" method="post" class="form-horizontal">
		  <div class="form-group">
            <label class="control-label col-sm-2" for="email">Name:</label>
            <div class="col-sm-10">
              <input type="text" name="m_name" value="<?php echo $row['m_name']; ?>" class="form-control" id="addName" placeholder="Enter Manufacturer Name" required>
            </div>
          </div>
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Update</button>
			  <a href="manufacturers.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 

</div>
</div>
<?php
	include_once "footer.php";

?>