<?php
 
	include_once "header.php";
	

	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
		}
	}
		

   
if(isset($_POST['submit']))
{
$name=$_POST['cust_name'];
$email=$_POST['cust_email'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];

$sql="INSERT INTO customers (cust_name, cust_email, mobile, address) VALUES('$name', '$email', '$mobile', '$address')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:view_customer.php");
$conn->close();
	
}


?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add Customer Information</h1>
      <form action="" method="post" class="form-horizontal">
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Customer name:</label>
            <div class="col-sm-8">
              <input type="text" name="cust_name" class="form-control" id="addname" placeholder="Enter Customer Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Customer email:</label>
            <div class="col-sm-8">
              <input type="text" name="cust_email" class="form-control" id="addemail" placeholder="Enter Customer Email" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Mobile No:</label>
            <div class="col-sm-8">
              <input onkeyup="numberOnly(this)" name="mobile" class="form-control" id="addmobile" placeholder="Enter Customer Mobile No" required>
            </div>
          </div>
		  
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Address:</label>
            <div class="col-sm-8">
			 <textarea name="address" class="form-control" id="addaddress" placeholder="Enter Customer Address" required></textarea>
            </div>
          </div>
		  
			<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
			
              <button type="submit" name="submit" class="btn btn-success" >Submit</button>
			  <a href="view_customer.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
<?php
	include_once "footer.php";
?>
<script>
function numberOnly(input) {
	var regex = /[^0-9]/g;
	input.value = input.value.replace(regex, "");
}
</script>