
<?php

require_once 'config/config.php';

if(isset($_POST['submit']))
{
//$pid=$_POST['p_id'];
$name=$_POST['user_name'];
$email=$_POST['user_email'];
$password=$_POST['password'];

$sql="INSERT INTO user (user_name, user_email, password) VALUES('$name','$email','$password')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:login.php");
$conn->close();
	
}
?> 





<!DOCTYPE html>
<html lang="en">
<head>
  <title>CMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
 
</head>
<body class="Login">
  <section class="container">
  <h1 class="center">SignUp</h1>
    <form action="" method="post" class="loginForm">
      <img class="img-responsive logo" src="img/logo.png" alt="">
      <div class="form-group">
        <label for="name">User Name:</label>
        <input type="text" name="user_name" class="form-control" id="name">
      </div>
      <div class="form-group">
        <label for="phone">Email address:</label>
        <input type="text" name="user_email" class="form-control" id="phone">
      </div>
      
      <div class="form-group">
        <label for="pwd">Password:</label>
        <input type="password" name="password" class="form-control" id="pwd">
      </div>
      <div class="checkbox">
        <label><input type="checkbox"> Remember me</label>
      </div>
      <input type="submit" name="submit" class="btn btn-default" value="Sign Up">
    </form>
  </section>
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>