<?php
include_once "header.php";

	if( !isset( $_SESSION['type'] )){
		//show nothing
		header( 'Location:logout.php' );
	} else {
		if( $_SESSION['type'] == 1 ){
			//admin
		} else {
			header( 'Location:logout.php' );
		}
	}

	
   
if(isset($_POST['submit']))
{
$name=$_POST['user_name'];
$email=$_POST['user_email'];
$password=$_POST['password'];
$mobile=$_POST['mobile'];
$sql="INSERT INTO user (user_name, user_email, password, mobile) VALUES('$name', '$email', '$password', '$mobile')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

header("Location:view_user.php");
$conn->close();
	
}


?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Add User Information</h1>
      <form action="" method="post" class="form-horizontal">
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">User name:</label>
            <div class="col-sm-8">
              <input type="text" name="user_name" class="form-control" id="addname" placeholder="Enter User Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">User email:</label>
            <div class="col-sm-8">
              <input type="text" name="user_email" class="form-control" id="addemail" placeholder="Enter User Email" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Password:</label>
            <div class="col-sm-8">
              <input type="password" name="password" class="form-control" id="addpassword" placeholder="Enter User Password" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Mobile No:</label>
            <div class="col-sm-8">
              <input onkeyup="numberOnly(this)" name="mobile"  class="form-control" id="addmobile" placeholder="Enter User Mobile No" required>
            </div>
          </div>
		  
			<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Submit</button>
			  <a href="view_user.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
<?php
	include_once "footer.php";
?>
<script>
function numberOnly(input) {
	var regex = /[^0-9]/g;
	input.value = input.value.replace(regex, "");
}
</script>