
<?php
include_once "header.php";
require_once 'config/config.php';

//if(isset($_SESSION['user_id']))

$user_id = $_SESSION['user_id'];

//echo "user".$user_id;

if (isset($_POST['submit']))
{

$oldPassword=$_POST['oldpassword'];
$newPassword=$_POST['newpassword'];
$confirmPassword=$_POST['confirmpassword'];

$sql="SELECT password FROM user WHERE password='$oldPassword'";
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
$row = mysqli_fetch_array($result);

echo $row['password'];

if($row['password']==$oldPassword){
	//echo "-------true";

	$sql2="UPDATE user SET password='$newPassword' WHERE user_id='$user_id'";

		if(mysqli_query($conn, $sql2)){
			echo "Records were updated successfully.";
		} else {
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
		}
}

}
?>
 <?php 
		include_once "sides.php";

	?>
<body class="Login">
  <section class="container">
    <form action="" method="post" class="loginForm">
      <!--img class="img-responsive logo" src="img/logo.png" alt=""-->
	  <h1 class="formHedings">Change Password</h1>
	   <div class="form-group">
        <label for="pwd">Old Password:</label>
        <input type="password" name="oldpassword" class="form-control" id="opwd" required>
      </div>
      <div class="form-group">
        <label for="pwd">New Password:</label>
        <input type="password" name="newpassword" class="form-control" id="npwd" required>
      </div>
      <div class="form-group">
        <label for="pwd">Confirm Password:</label>
        <input type="password" name="confirmpassword" class="form-control" id="cpwd" required>
      </div>
      <div class="checkbox">
        <label><input type="checkbox"> Remember me</label>
      </div>
      <input type="submit" name="submit" class="btn btn-default" value="Login">
	  <center><a href="index.php" type="button" class="btn btn-success back">Back</a></center>
    </form>
  </section>
    <footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
</html>