

<?php
include_once "header.php";

if(isset($_GET['edit']))
{
	
$product_id = $_GET['edit'];

$sql="SELECT * FROM products WHERE product_id='$product_id'";

$result = mysqli_query($conn,$sql);


	   $row = mysqli_fetch_array($result); 
	   
}
   
if(isset($_POST['submit']))
{
$name=$_POST['product_name'];
$no=$_POST['serial_no'];
$quantity=$_POST['quantity'];
$m_id=$_POST['m_id'];
$master_id=$_POST['master_id'];

$sql="UPDATE products SET product_name='$name', serial_no='$no', quantity='$quantity', m_id='$m_id', master_id='$master_id' WHERE product_id='$product_id'";

if ($conn->query($sql) === TRUE) {
    echo "New record updated successfully";
	header("Location:view_product.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
	
}
//echo $product_id;

?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Product Information</h1>
	 <?php
$sql2 = "SELECT * FROM manufacturers";
$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

?>  

	 <?php
$m_id=$row['m_id'];
$sql3 = "SELECT * FROM product_masters WHERE m_id='$m_id'";
$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));

?>  

         <form action="" method="post" class="form-horizontal customform">
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Product Name:</label>
            <div class="col-sm-9">
              <input type="text" name="product_name" value="<?php echo $row['product_name']; ?>" class="form-control" id="addname" placeholder="Enter Product Name" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Serial No:</label>
            <div class="col-sm-9">
              <input type="text" name="serial_no" value="<?php echo $row['serial_no']; ?>" class="form-control" id="addno" placeholder="Enter Serial no" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Quantity:</label>
            <div class="col-sm-9">
              <input type="text" name="quantity" value="<?php echo $row['quantity']; ?>" class="form-control" id="addquantity" placeholder="Enter Quantity" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-9">
		
				<select name="m_id" id="m_id" class="form-control" required>
				<option value="">Select</option>
				<?php 
					while($row2=mysqli_fetch_array($result2))
					{	
				?>
					<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
				<?php
					echo '<script>jQuery("#m_id").val("'.$row['m_id'].'");</script>';
				  ?>  		  	  
			</div>	
		</div>  
		<div class="form-group">
		<label class="control-label col-sm-3" for="pwd">Model:</label>
		<div class="col-sm-9">		
			<select name="master_id" id="master_id" class="form-control" required>
			<option value="">Select</option>
		</select>

		</div>
		 
		</div>
 		  
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Update</button>
			  <a href="view_product.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
 
</div>
</div>
 
<?php
	include_once "footer.php";

?>

<script>

function updateModel(a) {
    //alert(a);
	
	var data = {
        mid: a
    };
	
	$('#master_id').empty();
	$('#master_id').append( '<option value="0">Select</option>' );
	
    try{
      $.ajax({
          type: "POST",
          url: "getModelById.php",
          data: data,
          success: function(data){
			//alert(data);
			var dataObj = JSON.parse(data);
			//alert(dataObj[0].id);
			
			$.each( dataObj, function(key,value) {
			  //alert(value.id + " : "  + value.name);
	  
			  $('#master_id').append( '<option value="'+value.id+'">'+value.name+'</option>' );
			}); 			 
          },
          fail: function(e){
            alert("Please try after sometime");
          }
      });
    } catch(e){
      
    }
  }

$(document).ready(function(){
	var c = $("#m_id").val();
	updateModel(c);
    $("#m_id").change(function(){
		var b = $(this).val()
        updateModel(b);
    });
});
</script>

<?php
			//echo '<script>jQuery("#master_id").val("'.$row['master_id'].'");</script>';
			echo '<script>
			$(document).ready(function(){
				//alert(jQuery("#master_id").length)
				setTimeout(function(){ 
			jQuery("#master_id").val('.$row['master_id'].');
			 }, 1000);
			})
			</script>';
			//echo $row['master_id'];
		  ?>