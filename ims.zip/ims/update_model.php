<?php
include_once "header.php";

if(isset($_GET['edit']))
{
	
$master_id = $_GET['edit'];

$sql="SELECT * FROM product_masters WHERE master_id='$master_id'";

$result = mysqli_query($conn,$sql);


	   $row = mysqli_fetch_array($result); 
	   
}
   
if(isset($_POST['submit']))
{
$id=$_POST['model_id'];
$name=$_POST['model_name'];
$price=$_POST['model_price'];
$m_id=$_POST['m_id'];

$sql="UPDATE product_masters SET model_id='$id', model_name='$name', model_price='$price', m_id='$m_id' WHERE master_id='$master_id'";

if ($conn->query($sql) === TRUE) {
    echo "New record updated successfully";
	header("Location:view_model.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
	
}


?> 
 

<?php
include_once "sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Model Information</h1>
	 <?php

$sql2 = "SELECT * FROM manufacturers";
$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

?>  


         <form action="" method="post" class="form-horizontal customform">
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="email">Model Id:</label>
            <div class="col-sm-8">
              <input type="text" name="model_id" value="<?php echo $row['model_id']; ?>" class="form-control" id="addid" placeholder="Enter Manufacturer Name" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Name:</label>
            <div class="col-sm-8">
              <input type="text" name="model_name" value="<?php echo $row['model_name']; ?>" class="form-control" id="addname" placeholder="Enter place" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Model Price:</label>
            <div class="col-sm-8">
              <input type="text" name="model_price" value="<?php echo $row['model_price']; ?>" class="form-control" id="addprice" placeholder="Enter place" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Manufacturers:</label>
			<div class="col-sm-8">
		
				<select name="m_id" id="m_id" class="form-control" required>
				<option value="">Select</option>
				<?php 
					while($row2=mysqli_fetch_array($result2))
					{	
				?>
					<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
			</div>
			</div>
		  <?php
			echo '<script>jQuery("#m_id").val("'.$row['m_id'].'");</script>';
		  ?>
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Update</button>
			  <a href="view_model.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
</div>
<?php
	include_once "footer.php";

?>