<?php
include_once "header.php";



if(isset($_GET['edit']))
{
	
$cust_id = $_GET['edit'];

$sql="SELECT cust_name, cust_email, mobile, address FROM customers WHERE cust_id='$cust_id'";

$result = mysqli_query($conn,$sql);


	   $row = mysqli_fetch_array($result); 
}
	

if(isset($_POST['submit']))
{
$name=$_POST['cust_name'];
$email=$_POST['cust_email'];
$mobile=$_POST['mobile'];
$address=$_POST['address'];

$sql="UPDATE customers SET cust_name='$name', cust_email='$email', mobile='$mobile', address='$address' WHERE cust_id='$cust_id'";

if ($conn->query($sql) === TRUE) {
    echo "New record updated successfully";
	header("Location:view_customer.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
	
}


?> 

<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "sides.php";

	?>
<div class="container-fluid text-center user">    
  <div class="row content">
    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <h1>Update Customer Information</h1>
         <form action="" method="post" class="form-horizontal">
		  <div class="form-group">
            <label class="control-label col-sm-2" for="email">Name:</label>
            <div class="col-sm-10">
              <input type="text" name="cust_name" value="<?php echo $row['cust_name']; ?>" class="form-control" id="addName" placeholder="Enter Customer Name" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email:</label>
            <div class="col-sm-10">
              <input type="text" name="cust_email" value="<?php echo $row['cust_email']; ?>" class="form-control" id="addemail" placeholder="Enter Customer Email" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-2" for="email">Mobile:</label>
            <div class="col-sm-10">
              <input onkeyup="numberOnly(this)" name="mobile" value="<?php echo $row['mobile']; ?>" class="form-control" id="addMobile" placeholder="Enter Customer Mobile" required>
            </div>
          </div>
		  
		   <div class="form-group">
            <label class="control-label col-sm-2" for="email">Address:</label>
            <div class="col-sm-10">
              <textarea name="address"  class="form-control" id="addAddress" placeholder="Enter Customer Address" required><?php echo $row['address'];?></textarea>
            </div>
          </div>
		   
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" name="submit" class="btn btn-success" >Update</button>
			  <a href="view_customer.php" type="button" class="btn btn-success back">Back</a>
            </div>
          </div>
         
        </form> 
    </div>
 
  </div>
</div>

<?php
	include_once "footer.php";

?>
<script>
function numberOnly(input) {
	var regex = /[^0-9]/g;
	input.value = input.value.replace(regex, "");
}
</script>