
<?php
include_once "includes/header.php";
session_start();

$user_email = $_SESSION['user_email'];

if (isset($_POST['submit']))
{ 

	$oldPassword=$_POST['oldpassword'];
	$newPassword=$_POST['newpassword'];
	$confirmPassword=$_POST['confirmpassword'];
	
	$sql = "SELECT * FROM user WHERE user_email='$user_email' AND user_password='$oldPassword' AND active='1'";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	$row = mysqli_fetch_array($result);


	if($row['user_password']==$oldPassword)
	{
		//echo "-------true";

			$sql2="UPDATE user SET user_password='$newPassword' WHERE user_email='$user_email' AND active='1'";

			if(mysqli_query($conn, $sql2))
			{
				echo "Records were updated successfully.";
			} else {
				echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
			}
	} else {
	  echo "Old User Password does not match!";
	}

}
?>
<body class="Login">
  <section class="container">
     <form id="myform" action="" method="post" class="loginForm" onsubmit="return validateForm();">
      <!--img class="img-responsive logo" src="img/logo.png" alt=""-->
	  <h1 class="formHedings">Change Password</h1>
	   <div class="form-group">
        <label for="pwd">Old Password:</label>
        <input type="password" name="oldpassword" class="form-control" id="opwd" required>
      </div>
      <div class="form-group">
        <label for="pwd">New Password:</label>
        <input type="password" name="newpassword" class="form-control" id="npwd" required>
      </div>
      <div class="form-group">
        <label for="pwd">Confirm Password:</label>
        <input type="password" name="confirmpassword" class="form-control" id="cpwd" required>
      </div>
     
      <input type="submit" name="submit" class="btn btn-default" value="Change Password">
	  <!--center><a href="index.php" type="button" class="btn btn-success back">Back</a></center-->
    </form>
  </section>
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
  <script>
  function validateForm()
{	
	//check for empty fields
	if( $('#opwd').val() == '' ){
		alert( 'Old Password cannot be blank!' );
		return false;
	}
	
	if( $('#npwd').val() == '' ){
		alert( 'New Password cannot be blank!' );
		return false;
	}
	
	if( $('#cpwd').val() == '' ){
		alert( 'Confirm Password cannot be blank!' );
		return false;
	}
	
	
	
	if($('#npwd').val() == $('#opwd').val())
	{
		$(".new").removeClass('hide');
        alert('Please change your New Password!');
        return false;
	}
	else if($('#npwd').val() != $('#cpwd').val())
	{
		$(".new").removeClass('hide');
        alert('New Password and Confirm Password does not match!');
        return false;
	}
	
	
}

 </script>

</html>