<?php
include_once "includes/header.php";

if(isset($_GET['edit'])){
  $id = $_GET['edit'];

$sql="SELECT tbl_school_master.school_master_id, tbl_school_master.school_name, tbl_school_master.school_address, tbl_school_master.school_email, tbl_school_master.school_website, tbl_school_master.school_contact, tbl_school_master.gender_id, tbl_school_master.medium_id, tbl_school_master.board_id, tbl_school_master.activity_id, tbl_school_master.school_annual_fees,
tbl_school.teacher_stud_ratio, tbl_school.student_count, tbl_school.school_timing, tbl_school.classes, tbl_school.establish_in
FROM tbl_school_master
INNER JOIN tbl_school ON tbl_school_master.school_master_id = tbl_school.school_master_id WHERE tbl_school_master.school_master_id='$id'";
$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

  //$result = mysqli_query($conn,$sql);

  $row = mysqli_fetch_array($result); 
}
	

if(isset($_POST['submit']))
	{
	$school_name= addslashes($_POST['school_name']);
	$school_address=$_POST['school_address'];
	$school_email=$_POST['school_email'];
	$school_website=$_POST['school_website'];

	$school_contact=$_POST['school_contact'];
	$gender_id=$_POST['gender_id'];
	$medium_id=$_POST['medium_id'];
	$board_id=$_POST['board_id'];
	$activity_id=$_POST['activity_id'];
	$school_annual_fees=$_POST['school_annual_fees'];

	$teacher_stud_ratio=$_POST['teacher_stud_ratio'];

	$student_count=$_POST['student_count'];
	$school_timing=$_POST['school_timing'];
	$classes=$_POST['classes'];
	$establish_in=$_POST['establish_in'];

		$sql="UPDATE tbl_school_master SET school_name='$school_name', school_address='$school_address', school_email='$school_email', school_website='$school_website', school_contact='$school_contact', gender_id='$gender_id', medium_id='$medium_id', board_id='$board_id', activity_id='$activity_id', school_annual_fees='$school_annual_fees' WHERE school_master_id='$id'";

		if ($conn->query($sql) === TRUE) {
			echo "New record updated successfully";
			header("Location:view_info.php");
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$sql1="UPDATE tbl_school SET teacher_stud_ratio='$teacher_stud_ratio', student_count='$student_count', school_timing='$school_timing', classes='$classes', establish_in='$establish_in' WHERE school_master_id='$id'";

		if ($conn->query($sql1) === TRUE) {
			echo "New record updated successfully";
			header("Location:view_info.php");
		} else {
			echo "Error: " . $sql1 . "<br>" . $conn->error;
		}
$conn->close();
	
	}


?> 

<div class="container-fluid text-center user">    
  <div class="row content">
    <!--?php 
		include_once "includes/sides.php";

	?-->

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <center><h1>Update School Information</h1></center>
         <form action="" method="post" class="form-horizontal" id="schoolForm">
		 
		 
		 
		 <div class="form-group">
            <label class="control-label col-sm-4" for="email">School's name:</label>
            <div class="col-sm-8">
              <input type="text" onkeyup="lattersOnly(this)" data-validation="alphanumeric" data-validation-allowing="-'.() " name="school_name" value="<?php echo $row['school_name']; ?>" class="form-control" id="addname" placeholder="Enter School's Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">School's Address:</label>
            <div class="col-sm-8">
              <input type="text" name="school_address" value="<?php echo $row['school_address']; ?>" class="form-control" id="addaddress" placeholder="Enter school's Address" required>
            </div>
          </div>
		  
		  
		   <div class="form-group">
            <label class="control-label col-sm-4" for="email">School's Email:</label>
            <div class="col-sm-8">
              <input type="text" name="school_email" value="<?php echo $row['school_email']; ?>" class="form-control" id="addemail" placeholder="Enter school's Email">
			  <p class= "warning hide">Enter your valid email address.</p>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">School's Website:</label>
            <div class="col-sm-8">
              <input type="text" name="school_website" value="<?php echo $row['school_website']; ?>" class="form-control" id="addurl" placeholder="Enter school's Website">
			  <p class= "warning hide">Enter your valid web address.</p>
            </div>
          </div>
		  
		  	<div class="form-group">
            <label class="control-label col-sm-4" for="email">School's Contact:</label>
            <div class="col-sm-8">
				<div class="add_img">
				  <input type "text" name="school_contact" onkeyup="numberOnly(this)" value="<?php echo $row['school_contact']; ?>" class="form-control" id="addmobile" placeholder="Enter school's Contact No" required>
				   <!--img class="add plus" src="img/add.png" alt=""-->
				</div>
			</div>
			</div>
				
				  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Gender:</label>
			<div class="col-sm-8">
			
				<select name="gender_id" id="gender_id" class="form-control">
				<option value="">Select</option>
				<?php
					$sql2 = "SELECT * FROM tbl_gender";
					$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));

					while($row2=mysqli_fetch_array($result2)){	
				?>
					<option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
				<?php
					}
				?>
				</select>
			</div>
			</div>
			
			
			<div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Medium:</label>
			<div class="col-sm-8">
			
				<select name="medium_id" id="medium_id" class="form-control">
				<option value="">Select</option>
				<?php
					$sql3 = "SELECT * FROM tbl_medium";
					$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));

					while($row3=mysqli_fetch_array($result3)){	
				?>
					<option value="<?php echo $row3[0];?>"><?php echo $row3[1];?></option>
				<?php
					}
				?>
				</select>
			</div>
			</div>
			
			<div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Board:</label>
			<div class="col-sm-8">
			
				<select name="board_id" id="board_id" class="form-control" multiple>
				<!--option value="">Select</option-->
				<?php
				
				
					$sql4="SELECT * FROM tbl_board";
					$result4 = mysqli_query($conn, $sql4) or die("Error in Selecting " . mysqli_error($conn));
					while($row4=mysqli_fetch_array($result4))
					{	
						
				?>
					<option value="<?php echo $row4[0];?>"><?php echo $row4[1]?></option>
				<?php
					
				}
				?>
				</select>
			</div>
			</div>
			
			
				  <div class="form-group">
            <label class="control-label col-sm-3" for="pwd">Co Curricular Activity:</label>
			<div class="col-sm-8">
			
				<select name="activity_id" id="activity_id" class="form-control" multiple>
				
				<?php
					$sql5 = "SELECT * FROM tbl_co_curricular_activities";
					$result5 = mysqli_query($conn, $sql5) or die("Error in Selecting " . mysqli_error($conn));

					while($row5=mysqli_fetch_array($result5)){	
				?>
					<option value="<?php echo $row5[0];?>"><?php echo $row5[1];?></option>
				<?php
					}
				?>
				</select>
			</div>
			</div>
			
			 <div class="form-group">
            <label class="control-label col-sm-4" for="email">School's Annual Fees:</label>
            <div class="col-sm-8">
			 <input type="text" onkeyup="numberOnly(this)" name="school_annual_fees" value="<?php echo $row['school_annual_fees']; ?>" class="form-control" id="addfees" placeholder="Enter school's annual Fees">
			 <p class="warningLength hide">Enter range not more then 4.</p>
            </div>
          </div>
				
			 <div class="form-group">
            <label class="control-label col-sm-4" for="email">Teacher Student Ratio:</label>
            <div class="col-sm-8">
			 <input type="text" name="teacher_stud_ratio" onkeyup="numberOnly(this)" value="<?php echo $row['teacher_stud_ratio']; ?>" class="form-control inline" id="addratio1">
			 
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Student Count:</label>
            <div class="col-sm-8">
			 <input type="text" onkeyup="numberOnly(this)" name="student_count" value="<?php echo $row['student_count']; ?>" class="form-control" id="addcount" placeholder="Enter Student Count">
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">School Timing:</label>
            <div class="col-sm-8">
			 <input type="text" name="school_timing" value="<?php echo $row['school_timing']; ?>" class="form-control" id="addestiming" placeholder="Enter Establish In">
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Classes:</label>
            <div class="col-sm-8">
			 <input type="text" onkeyup="numberOnly(this)" data-validation="length" data-validation-length="1-12" name="classes" value="<?php echo $row['classes']; ?>" class="form-control" id="addclass" placeholder="Enter Classes" required>
			 <p class="range hide">Invalide Range</p>
            </div>
          </div>
		  
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Establish In:</label>
            <div class="col-sm-8 jkg">
			 <input type="text" onkeyup="numberOnly(this)" name="establish_in" value="<?php echo $row['establish_in']; ?>" class="form-control" id="addestablish" placeholder="Enter Establish In">
			 <p class="warningLength hide">Enter range not more then 4.</p>
            </div>
          </div>
		  
		  <?php
			echo '<script>jQuery("#gender_id").val("'.$row['gender_id'].'");</script>';
			echo '<script>jQuery("#medium_id").val("'.$row['medium_id'].'");</script>';
			echo '<script>jQuery("#board_id").val("'.$row['board_id'].'");</script>';
			echo '<script>jQuery("#activity_id").val("'.$row['activity_id'].'");</script>';
		  ?>
		  
		  <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
			<center>
            <button type="submit" name="submit" class="btn btn-success" >Update</button>
			<a href="view_info.php" type="button" class="btn btn-success back">Back</a>
			</center>
            </div>
          </div>
         
        </form> 
    </div>
 

</div>
</div>
<!--?php
	include_once "includes/footer.php";

?-->
<script>

function lattersOnly(input) {
	
		var regex = /[^a-z-w w'w(w)w.w]/gi;
	    input.value = input.value.replace(regex, "");
}

function numberOnly(input) {
	
		var regex = /[^0-9-w,w:w]/g;
	    input.value = input.value.replace(regex, "");
	
}

function warningCheck(input,reg){
	$("#schoolForm").submit(function(e){
		var re = reg;
		var s_mail = $(input).val();
		if(!re.test(s_mail) && s_mail != ""){
			e.preventDefault();
			$(this).find(input).next().removeClass('hide')
		} else {
			$(this).find(input).next().addClass('hide')
		}
	})
}

function lengthCheck(input,length){
	$("#schoolForm").submit(function(e){
		var s_ratio = $(input).val().length;
		if(s_ratio > length){
			e.preventDefault();
			//alert($(input).parent().attr('class'));
			$(input).parent().find('.warningLength').removeClass('hide')
		} else {
			$(input).parent().find('.warningLength').addClass('hide')
		}
	})
}

function stringSplit(input) {
	var str = input;
    var res = str.split("-");
	//console.log(res[0]);
	
	if(res[0] >=1 && res[0]<=12 && res[1] >=1 && res[1]<=12){
			$('.range').addClass('hide');
			return true;
	}
	else{
		$('.range').removeClass('hide');
		return false;
	}
	
	if(res[0] == res[1]){
		$('.range').removeClass('hide');
	}
	
		
}


$(document).ready(function(){
	
	
	$('#addclass').blur(function(){
	var s_class = $(this).val();
	stringSplit(s_class)
})

$("#schoolForm").submit(function(e){
	var s_class = $('#addclass').val();
	var isTrue = stringSplit(s_class);
	
	if(isTrue != true){
		e.preventDefault();
	}
	
});
	
	
	var re = new RegExp (/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
	var urlPattern = new RegExp("(http|ftp|https)://[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:/~+#-]*[\w@?^=%&amp;/~+#-])?")
		
	warningCheck('#addemail',re);
	warningCheck('#addurl',urlPattern);
	
	lengthCheck('#addfees',4);
	lengthCheck('#addestablish',4);
	})
</script>
