<?php 
	include_once "includes/header.php";
	
/*	if( $_SESSION['type'] == 1 || $_SESSION['type'] == 100 ){
		//admin
	} else {
		header( 'Location:logout.php' );
	}
	
  */


?>
  
<div class="container-fluid text-center user">    
  <div class="row content">
    <?php 
		include_once "includes/sides.php";

	?>
    <div class="col-sm-10 text-left"> 
      <h1>User Permission Management</h1>
 
      <div class="clear"></div>
      <!--a href="add_manufacturers.php" type="button" class="btn btn-success addUser">Add Manufacturer</a-->
        <table class="table table-hover userDashTable rwd-table">
        <thead>
          <tr>   
            <th>User Name</th>
            <th>Module 1</th>
			<th>Module 2</th>
			<th>Module 3</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
    
<?php  

	$sql="SELECT * FROM user_master_tbl";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	while($row=mysqli_fetch_array($result))
	{  
?>
        <tr data-userid="<?php echo $row['user_id']; ?>">
		  <!--td>< ?php echo $row['m_id']; ?></td-->
		 
          <td><?php echo $row['user_name']; ?></td>
		  
		  <td> 
		  <input type="checkbox" name="student_model" id="5" class="stu_model" value="model"> Student Model <br />
		  <?php
				$sql1="SELECT * FROM user_sub_module_tbl WHERE module_id='5'";
				$result1 = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));
				while($row1=mysqli_fetch_array($result1)){
					
					
				
			 echo "<input type='checkbox' class='add' name='".$row1['sub_module_id']."' id='".$row1['sub_module_id']."' value='".$row1['sub_module_name']."'>".$row1['sub_module_name'];
				}
		  ?>
		  </td>
		  <td> 
		  <input type="checkbox" name="student_account" id="6" class="stu_account" value="account"> Student Account <br />
		  <?php
				$sql2="SELECT * FROM user_sub_module_tbl WHERE module_id='6'";
				$result2 = mysqli_query($conn, $sql2) or die("Error in Selecting " . mysqli_error($conn));
				while($row2=mysqli_fetch_array($result2)){
				
			 echo "<input type='checkbox' class='add_account' name='".$row2['sub_module_id']."' id='".$row2['sub_module_id']."' value='".$row2['sub_module_name']."'>".$row2['sub_module_name'];
				}
		  ?>
		  </td>
		  <td> 
		  <input type="checkbox" name="student_admission" id="7" class="stu_admision" value="admission"> Student Admission <br />
		  	 
		  <?php
				$sql3="SELECT * FROM user_sub_module_tbl WHERE module_id='7'";
				$result3 = mysqli_query($conn, $sql3) or die("Error in Selecting " . mysqli_error($conn));
				while($row3=mysqli_fetch_array($result3)){
				
			 echo "<input type='checkbox' class='add_admission' name='".$row3['sub_module_id']."' id='".$row3['sub_module_id']."' value='".$row3['sub_module_name']."'>".$row3['sub_module_name'];
				}
		  ?>
		  </td>
		  <td>
		  <button type="submit" name="submit" class="btn btn-success permission" >Save</button>
		  </td>
<?php 
    }

?>			
		</tr>
		
<label class="control-label col-sm-3"></label>
            <div class="col-sm-8">
             
            </div>
			
			
        </tbody>
      </table>
    </div>
 
  </div>
</div>

 <script>
 
 
$(document).ready(function(){
	   $('.permission').click(function(){
			var button = $(this);
			var valueStore = studentModelDataCollect(button);
			
		
			var data = {
				
				json: valueStore
			};			
			//alert(JSON.stringify(valueStore));
			
		try{
        $.ajax({
          type: "POST",
          url: "get_store_values.php",
          data: data,
          success: function(data){
              //alert( data );
          },
          fail: function(e){
            alert("Please try after sometime");
          }
      });
    } catch(e){
      //alert(e);
    }
  
	   
					
	});
		       
});
	
function studentModelDataCollect(button){
	
	var userName = $(button).parents('tr').attr('data-userid');//find('td').eq(0).text();
	
	var obj = {};
	obj.userId = userName;
	
	//add modules
	obj.modules = [];
	obj.modules[0] = {};
	obj.modules[1] = {};
	obj.modules[2] = {};
	
	//populate sub modules
	obj.modules[0].moduleId = $(button).parents('tr').find('td').eq(1).find('.stu_model').attr('id');
	obj.modules[0].submodules = [];
	$(button).parents('tr').find('td').eq(1).find('.add').each(function(){
		if($(this).prop("checked")){
			obj.modules[0].submodules.push($(this).attr("id"));
		}
	});
	//student account
	obj.modules[1].moduleId = $(button).parents('tr').find('td').eq(2).find('.stu_account').attr('id');
	obj.modules[1].submodules = [];
	$(button).parents('tr').find('td').eq(2).find('.add_account').each(function(){
		if($(this).prop("checked")){
			obj.modules[1].submodules.push($(this).attr("id")); 
		}
	});
	//student admission
	obj.modules[2].moduleId = $(button).parents('tr').find('td').eq(3).find('.stu_admision').attr('id');
	obj.modules[2].submodules = [];
	$(button).parents('tr').find('td').eq(3).find('.add_admission').each(function(){
		if($(this).prop("checked")){
			obj.modules[2].submodules.push($(this).attr("id"));//+':'+$(this).prop("checked")); 
		}
	});
	
	return obj;
 }

</script>

<?php
	include_once "includes/footer.php";

?>