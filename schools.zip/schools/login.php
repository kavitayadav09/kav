
<?php
require_once 'config/config.php';
session_start();

$msg = "";

if( isset( $_POST['submit'] ) ){
	$user_email = $_POST['user_email'];
	$password = $_POST['user_password'];
	$sql = "SELECT * FROM user WHERE user_email='$user_email' AND user_password='$password' AND active='1'";

	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

	if($row = mysqli_fetch_array($result)){
		$_SESSION['user_email']=$row['user_email'];
		$_SESSION['type']=$row['type'];
		echo "<h1>Login successfully!!!!!</h1>";
		header("Location:change_password.php");
		exit();
	} else {
		$msg = "Wrong Credentials!";
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>CMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"
		integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
		crossorigin="anonymous"></script>
 
</head>

<body class="Login">
	<section class="container">
		<form action="" method="POST" class="loginForm" id="loginForm" onsubmit="return validateForm();">
			<h5><?php echo $msg;?></h5>
		  <h1 class="formHedings">Login</h1>
		  
		  <!--  div class="form-group">
			<label for="user_id">User Id:</label>
			<input type="text" name="user_id" class="form-control" id="user_id" required>
		  </div-->
		  
		  <div class="form-group">
			<label for="email">Email:</label>
			<input type="text" name="user_email" class="form-control" id="addemail" required>
		  </div>
		  
		  <div class="form-group">
			<label for="pwd">Password:</label>
			<input type="password" name="user_password" class="form-control" id="user_password" required>
		  </div>
		  <div class="checkbox">
			<label><input type="checkbox"> Remember me</label>
		  </div>
		  <input type="submit" name="submit" class="btn btn-default" value="Login">
		  <center><a href="forgot_password.php"  class="back">forgot Password</a></center>
		</form>
	</section>
</body>

 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
 <script>
function validateForm()
{	
	//check for empty fields
	if( $('#addemail').val() == '' ){
		alert( 'User ID cannot be blank!' );
		return false;
	}
	
	if( $('#user_password').val() == '' ){
		alert( 'Password cannot be blank!' );
		return false;
	}
	
	//check for other valdations
	//for Email
	var email = $('#addemail').val();
	var regEx = new RegExp (/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
	if( !regEx.test( email ) ){
		alert( "Please enter proper Email!" );
		return false;
	}
	
	return true;
}

/*function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
		return false;

	return true;
}*/

$(document).ready(function(){
	//for Mobile
	$("#user_id").attr('maxlength','10');
	$('#user_id').keypress(function (e) {
		return isNumberKey(e);
	});
});

</script>
 
</html>