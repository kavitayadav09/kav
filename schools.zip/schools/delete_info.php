<?php
	require_once 'config/config.php';
	
	if(isset($_GET['delete'])){
	
	$id = $_GET['delete'];
	$sql = "DELETE FROM tbl_school_master WHERE school_master_id='$id'";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	
	$sql1 = "DELETE FROM tbl_school WHERE school_master_id='$id'";
	$result1 = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));
}

 header('location:view_info.php');
?>