<?php
require_once 'config/config.php';

$values=$_POST['json'];
//print_r($values);
//echo $values['userId'];
//print_r($values['modules']);
//print_r($values['modules']);

for($i=0; $i<count($values['modules']); $i++)
{
		$sql = "INSERT INTO user_permission_tbl ( user_id, module_id) VALUES( '$values['userId']', '$values['modules']')";
			if ($conn->query($sql) === TRUE) {
				$msg = "New record created successfully";
			} else {
				$msg = "Error: " . $sql . "<br>" . $conn->error;
			}
		}
	
	
	$conn->close();


?>