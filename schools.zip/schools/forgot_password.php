<?php

require_once 'config/config.php';


if (isset($_POST['submit']))
{
	$user_email = $_POST['user_email'];
	
	$sql="SELECT * FROM user WHERE user_email='$user_email' AND user_active='1'";
	$result = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
    $row = mysqli_fetch_array($result);
	
	//echo $row['user_name'];
	if($row['user_email'] != 'undefined'){
		//generete a new password
		$random = rand(5000, 10000);
		
		$newPassword = $random;
		echo $newPassword;
		$sql2="UPDATE user SET user_password='$newPassword' WHERE user_email='$user_email' AND user_active='1'";

		if(mysqli_query($conn, $sql2)){
			echo "Records were updated successfully.";
      
			//SEND EMAIL
			
		} else {
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
		}

	}	else{
	 echo "This User Id does not exist";
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>CMS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css.map" rel="stylesheet">
  <link rel="stylesheet" href="css/custom.css">
  
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"
		integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
		crossorigin="anonymous"></script>
 
</head>

<body class="Login">
  <section class="container">
    <form action="" method="post" class="loginForm" id="loginForm" onsubmit="return validateForm();">
      <!--img class="img-responsive logo" src="img/logo.png" alt=""-->
	 <h1 class="formHedings">Forgot Password</h1>
      <div class="form-group">
        <label for="email">User Email:</label>
        <input type="text" name="user_email" class="form-control" id="user_email" required>
      </div>
	  <input type="submit" name="submit" class="btn btn-default" value="Submit">
	  <center><a href="index.php" type="button" class="btn btn-success back">Back</a></center>
    </form>
  </section>
 
</body>
 <script src="script/jquery.js"></script>
 <script src="script/bootstrap.min.js"></script>
 <script src="script/custom.js"></script>
 
  <script>
function validateForm()
{	
	//check for empty fields
	if( $('#user_email').val() == '' ){
		alert( 'User Email cannot be blank!' );
		return false;
	}
	
	//check for other valdations
	//for Email
	var email = $('#user_email').val();
	var regEx = new RegExp (/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
	if( !regEx.test( email ) ){
		alert( "Please enter proper Email!" );
		return false;
	}
	
	return true;
}

/*function isNumberKey(evt)
{
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
		return false;

	return true;
}*/

$(document).ready(function(){
	//for Mobile
	$("#user_id").attr('maxlength','10');
	$('#user_id').keypress(function (e) {
		return isNumberKey(e);
	});
});
 </script>
</html>