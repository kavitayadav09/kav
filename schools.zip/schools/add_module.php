<?php

include_once 'includes/header.php';

if(isset($_POST['submit']))
{
$module_name=$_POST['module_name'];
$module_desc=$_POST['module_desc'];

$sql="INSERT INTO user_module_tbl (module_name, module_desc) VALUES('$module_name','$module_desc')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

//header("Location:viewtags.php");
$conn->close();
	
}

?>

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <center><h1>Add Module</h1></center>
      <form action="" method="post" class="form-horizontal">
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Module name:</label>
            <div class="col-sm-8">
              <input type="text" name="module_name" class="form-control" id="module_name" placeholder="Enter Module Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Module description:</label>
            <div class="col-sm-8">
              <input type="text" name="module_desc" class="form-control" id="module_desc" placeholder="Enter Module Description" required>
            </div>
          </div>
		  
			<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
			
            <button type="submit" name="submit" class="btn btn-success" >Submit</button>
            
			  <!--a href="view_customer.php" type="button" class="btn btn-success back">Back</a-->
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
<?php
	include_once "includes/footer.php";
?>
