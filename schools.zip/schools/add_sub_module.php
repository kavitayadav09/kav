<?php

include_once 'includes/header.php';

if(isset($_POST['submit']))
{
$sub_module_name=$_POST['sub_module_name'];
$sub_module_desc=$_POST['sub_module_desc'];
$module_id=$_POST['module_id'];

$sql="INSERT INTO user_sub_module_tbl (module_id, sub_module_name, sub_module_desc) VALUES('$module_id', '$sub_module_name','$sub_module_desc')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

//header("Location:viewtags.php");
$conn->close();
	
}

?>

<?php
include_once "includes/sides.php";
?>
<div class="col-sm-10 text-center user">    
  

    <div class="col-sm-6 text-left marginAuto AddUser"> 
      <center><h1>Add Sub Module</h1></center>
      <form action="" method="post" class="form-horizontal">
	  
	    
		  <div class="form-group">
          <label class="control-label col-sm-4" for="pwd">Module :</label>
          <div class="col-sm-8">
              <select name="module_id" class="gender_id form-control" id="module_id">
                <option value="">Select</option>
		      <?php 
					
                    $sql1 = "SELECT * FROM user_module_tbl";
                    $result1 = mysqli_query($conn, $sql1) or die("Error in Selecting " . mysqli_error($conn));
                    while($row1=mysqli_fetch_array($result1)){ 
					
                 ?>
		   
                 <option value="<?php echo $row1[0];?>"><?php echo $row1[1];?></option>
                  <?php
                    }
					
                  ?>
				
              </select>
			
          </div>
      </div> 
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Sub module name:</label>
            <div class="col-sm-8">
              <input type="text" name="sub_module_name" class="form-control" id="sub_module_name" placeholder="Enter Sub Module Name" required>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-sm-4" for="email">Sub module description:</label>
            <div class="col-sm-8">
              <input type="text" name="sub_module_desc" class="form-control" id="sub_module_desc" placeholder="Enter Sub Module Description">
            </div>
          </div>
		
			<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
			
            <button type="submit" name="submit" class="btn btn-success" >Submit</button>
            
			  <!--a href="view_customer.php" type="button" class="btn btn-success back">Back</a-->
            </div>
          </div>
         
        </form> 
    </div>
 
</div>
<?php
	include_once "includes/footer.php";
?>
