<?php

define("BASEPATH", 'http://localhost:8012/' );//http://techie-experts.com/ims/
//define("PROJECT_ROOT", 'ims/trunk/dev/');//

//$base_url = BASEPATH.PROJECT_ROOT;//"http://192.168.1.75:8012/post_mortem_mgmt/trunk/dev/";
//$project_root = PROJECT_ROOT;

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phplibrarydb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
?>