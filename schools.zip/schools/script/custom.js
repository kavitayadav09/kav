jQuery(document).ready(function(){
	/*$(".addUser").click(function(){
    	$(".addUserForm").slideToggle();
	});*/
})